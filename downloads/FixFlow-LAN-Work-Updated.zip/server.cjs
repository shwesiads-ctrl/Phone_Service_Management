var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// src/utils/imageUpload.ts
var MAX_IMAGE_BYTES = 2 * 1024 * 1024;
function rasterMime(binary) {
  const bytes = Array.from(binary.slice(0, 12), (c) => c.charCodeAt(0));
  if ([137, 80, 78, 71, 13, 10, 26, 10].every((v, i) => bytes[i] === v)) return "image/png";
  if (bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255) return "image/jpeg";
  if (binary.slice(0, 4) === "RIFF" && binary.slice(8, 12) === "WEBP") return "image/webp";
  return null;
}
function imageValidationError(value, allowUrl = true) {
  if (value === void 0 || value === "") return null;
  if (typeof value !== "string") return "Choose a PNG, JPEG or WebP image.";
  if (allowUrl && /^https?:\/\//i.test(value)) {
    try {
      const url = new URL(value);
      if (value.length <= 2048 && !url.username && !url.password) return null;
    } catch {
    }
    return "Enter a valid image URL.";
  }
  const match = /^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/]*={0,2})$/i.exec(value);
  if (!match) return "Choose a PNG, JPEG or WebP image.";
  if (match[2].length > Math.ceil(MAX_IMAGE_BYTES / 3) * 4) return "Image must be 2 MB or smaller.";
  try {
    const binary = atob(match[2]);
    if (binary.length > MAX_IMAGE_BYTES) return "Image must be 2 MB or smaller.";
    if (rasterMime(binary) !== match[1].toLowerCase()) return "Image content does not match its file type.";
  } catch {
    return "Image data is invalid.";
  }
  return null;
}

// src/server/recovery.ts
var import_node_fs = __toESM(require("node:fs"), 1);
var import_node_path = __toESM(require("node:path"), 1);
var import_node_os = __toESM(require("node:os"), 1);
var import_node_crypto = require("node:crypto");
var RecoveryKeyStore = class _RecoveryKeyStore {
  constructor(directory, machineFingerprint = _RecoveryKeyStore.machineFingerprint()) {
    this.machineFingerprint = machineFingerprint;
    import_node_fs.default.mkdirSync(directory, { recursive: true, mode: 448 });
    this.file = import_node_path.default.join(directory, "password-recovery.json");
    if (import_node_fs.default.existsSync(this.file)) {
      const state = JSON.parse(import_node_fs.default.readFileSync(this.file, "utf8"));
      if (!state.installation_id || !Number.isSafeInteger(state.generation) || state.generation < 1 || !/^FFRK-[A-Za-z0-9_-]{43}$/.test(state.backup_key) || _RecoveryKeyStore.digest(state.backup_key) !== state.key_hash) throw new Error("Recovery key backup is unreadable. Restore the local security file before starting.");
      this.state = state;
      if (state.machine_fingerprint !== machineFingerprint) {
        this.state = this.newState((0, import_node_crypto.randomUUID)(), 1);
        this.save(this.state);
      }
    } else {
      this.state = this.newState((0, import_node_crypto.randomUUID)(), 1);
      this.save(this.state);
    }
  }
  static machineFingerprint() {
    const macs = Object.values(import_node_os.default.networkInterfaces()).flatMap((entries) => (entries || []).filter((info) => !info.internal && info.mac !== "00:00:00:00:00:00").map((info) => info.mac)).sort();
    return _RecoveryKeyStore.digest(`${import_node_os.default.hostname()}|${import_node_os.default.platform()}|${import_node_os.default.arch()}|${[...new Set(macs)].join(",")}`);
  }
  static digest(value) {
    return (0, import_node_crypto.createHash)("sha256").update(value).digest("hex");
  }
  newState(installation, generation) {
    const key = `FFRK-${(0, import_node_crypto.randomBytes)(32).toString("base64url")}`;
    return { installation_id: installation, machine_fingerprint: this.machineFingerprint, generation, created_at: (/* @__PURE__ */ new Date()).toISOString(), key_hash: _RecoveryKeyStore.digest(key), backup_key: key };
  }
  save(state) {
    const temporary = `${this.file}.${(0, import_node_crypto.randomUUID)()}.tmp`;
    import_node_fs.default.writeFileSync(temporary, JSON.stringify(state, null, 2), { mode: 384, flag: "wx" });
    import_node_fs.default.renameSync(temporary, this.file);
  }
  status() {
    return { installation_id: this.state.installation_id, generation: this.state.generation, created_at: this.state.created_at };
  }
  backup() {
    return { ...this.status(), key: this.state.backup_key };
  }
  verify(key) {
    if (typeof key !== "string" || !/^FFRK-[A-Za-z0-9_-]{43}$/.test(key)) return false;
    return (0, import_node_crypto.timingSafeEqual)(Buffer.from(_RecoveryKeyStore.digest(key), "hex"), Buffer.from(this.state.key_hash, "hex"));
  }
  rotate(action = () => () => {
  }) {
    const next = this.newState(this.state.installation_id, this.state.generation + 1);
    const temporary = `${this.file}.${(0, import_node_crypto.randomUUID)()}.tmp`;
    import_node_fs.default.writeFileSync(temporary, JSON.stringify(next, null, 2), { mode: 384, flag: "wx" });
    let rollback;
    try {
      rollback = action();
      import_node_fs.default.renameSync(temporary, this.file);
      this.state = next;
      return this.backup();
    } catch (error) {
      if (rollback) rollback();
      throw error;
    } finally {
      if (import_node_fs.default.existsSync(temporary)) import_node_fs.default.rmSync(temporary);
    }
  }
};

// src/server/passwords.ts
var import_node_crypto2 = require("node:crypto");
function hashPassword(password) {
  const salt = (0, import_node_crypto2.randomBytes)(16).toString("hex");
  return `scrypt$${salt}$${(0, import_node_crypto2.scryptSync)(password, salt, 64).toString("hex")}`;
}
function verifyPassword(password, stored) {
  if (typeof password !== "string") return false;
  if (!stored.startsWith("scrypt$")) return password === stored;
  const [, salt, digest] = stored.split("$");
  try {
    const expected = Buffer.from(digest, "hex");
    const actual = (0, import_node_crypto2.scryptSync)(password, salt, 64);
    return expected.length === actual.length && (0, import_node_crypto2.timingSafeEqual)(expected, actual);
  } catch {
    return false;
  }
}

// src/server/telegram.ts
var escapeTelegramHtml = (value) => String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
async function telegramRequest(token, method, body) {
  try {
    const response = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body || {}),
      signal: AbortSignal.timeout(1e4)
    });
    const data = await response.json();
    if (typeof data?.ok !== "boolean") return { ok: false, description: "Invalid response from Telegram." };
    if (!response.ok) data.ok = false;
    if (data.description) data.description = String(data.description).split(token).join("[redacted]");
    if (data.error_code === 409 && method === "getUpdates") data.description += " Chat detection requires polling; a webhook or another polling process may be active. Enter the Chat ID manually or resolve the other integration first.";
    return data;
  } catch {
    return { ok: false, description: "Telegram request timed out or failed. Check internet access and try again." };
  }
}
async function sendRawTelegramMessage(token, chatId, html) {
  const result = await telegramRequest(token, "sendMessage", { chat_id: chatId, text: html, parse_mode: "HTML" });
  if (!result.ok && result.error_code === 400 && /can't parse entities|unsupported start tag/i.test(result.description || "")) {
    const text = html.replace(/<[^>]+>/g, "").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");
    return telegramRequest(token, "sendMessage", { chat_id: chatId, text });
  }
  return result;
}

// server.ts
var import_express = __toESM(require("express"), 1);
var import_vite = require("vite");
var import_path2 = __toESM(require("path"), 1);
var import_fs2 = __toESM(require("fs"), 1);
var import_os = __toESM(require("os"), 1);
var import_node_crypto4 = require("node:crypto");
var import_child_process = require("child_process");

// src/utils/paymentDefaults.ts
var defaultPaymentSettings = {
  mode: "auto",
  active_profile: "thailand",
  thailand: {
    methods: [
      {
        id: "cash",
        name: "\u0E40\u0E07\u0E34\u0E19\u0E2A\u0E14 (Cash)",
        thai_name: "\u0E40\u0E07\u0E34\u0E19\u0E2A\u0E14 (Cash)",
        enabled: true,
        instructions: "\u0E0A\u0E33\u0E23\u0E30\u0E40\u0E07\u0E34\u0E19\u0E2A\u0E14\u0E17\u0E35\u0E48\u0E40\u0E04\u0E32\u0E19\u0E4C\u0E40\u0E15\u0E2D\u0E23\u0E4C\u0E28\u0E39\u0E19\u0E22\u0E4C\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23"
      },
      {
        id: "bank_transfer",
        name: "\u0E42\u0E2D\u0E19\u0E40\u0E07\u0E34\u0E19\u0E1C\u0E48\u0E32\u0E19\u0E18\u0E19\u0E32\u0E04\u0E32\u0E23 (Bank Transfer)",
        thai_name: "\u0E42\u0E2D\u0E19\u0E40\u0E07\u0E34\u0E19\u0E1C\u0E48\u0E32\u0E19\u0E18\u0E19\u0E32\u0E04\u0E32\u0E23 (Bank Transfer)",
        enabled: false,
        instructions: "Configure your verified payment account and bank-issued QR before enabling."
      },
      {
        id: "promptpay",
        name: "PromptPay",
        thai_name: "PromptPay",
        enabled: false,
        instructions: "Configure your verified payment account and bank-issued QR before enabling."
      },
      {
        id: "kplus",
        name: "K PLUS",
        thai_name: "K PLUS",
        enabled: false,
        instructions: "Configure your verified payment account and bank-issued QR before enabling."
      },
      {
        id: "scb_easy",
        name: "SCB EASY",
        thai_name: "SCB EASY",
        enabled: false,
        instructions: "Configure your verified payment account and bank-issued QR before enabling."
      },
      {
        id: "truemoney",
        name: "TrueMoney Wallet",
        thai_name: "TrueMoney Wallet",
        enabled: false,
        instructions: "Configure your verified payment account and bank-issued QR before enabling."
      },
      {
        id: "rabbit_line_pay",
        name: "Rabbit LINE Pay",
        thai_name: "Rabbit LINE Pay",
        enabled: false,
        instructions: "Configure your verified payment account and bank-issued QR before enabling."
      },
      {
        id: "shopeepay",
        name: "ShopeePay",
        thai_name: "ShopeePay",
        enabled: false,
        instructions: "Configure your verified payment account and bank-issued QR before enabling."
      },
      {
        id: "card",
        name: "\u0E1A\u0E31\u0E15\u0E23\u0E40\u0E04\u0E23\u0E14\u0E34\u0E15/\u0E40\u0E14\u0E1A\u0E34\u0E15 (Credit/Debit Card)",
        thai_name: "\u0E1A\u0E31\u0E15\u0E23\u0E40\u0E04\u0E23\u0E14\u0E34\u0E15/\u0E40\u0E14\u0E1A\u0E34\u0E15 (Credit/Debit Card)",
        enabled: false,
        instructions: "Configure your verified payment account and bank-issued QR before enabling."
      },
      {
        id: "other",
        name: "\u0E2D\u0E37\u0E48\u0E19\u0E46 (Other)",
        thai_name: "\u0E2D\u0E37\u0E48\u0E19\u0E46 (Other)",
        enabled: false,
        instructions: "Configure your verified payment account and bank-issued QR before enabling."
      }
    ]
  },
  myanmar: {
    methods: [
      {
        id: "kbz_pay",
        name: "KBZ Pay",
        enabled: false,
        instructions: "Configure your verified payment account and bank-issued QR before enabling."
      },
      {
        id: "wave_pay",
        name: "Wave Pay",
        enabled: false,
        instructions: "Configure your verified payment account and bank-issued QR before enabling."
      },
      {
        id: "aya_pay",
        name: "AYA Pay",
        enabled: false,
        instructions: "Configure your verified payment account and bank-issued QR before enabling."
      },
      {
        id: "cb_pay",
        name: "CB Pay",
        enabled: false,
        instructions: "Configure your verified payment account and bank-issued QR before enabling."
      },
      {
        id: "cash",
        name: "Cash",
        enabled: true,
        instructions: "Cash payment in Myanmar Kyats"
      },
      {
        id: "bank_transfer",
        name: "Bank Transfer",
        enabled: false,
        instructions: "Configure your verified payment account and bank-issued QR before enabling."
      }
    ]
  },
  china: {
    methods: [
      { id: "cash", name: "Cash / \u73B0\u91D1", enabled: true, instructions: "Cash payment at the counter." },
      { id: "alipay", name: "Alipay / \u652F\u4ED8\u5B9D", enabled: false, instructions: "Configure your verified Alipay account and merchant-issued QR." },
      { id: "wechat_pay", name: "WeChat Pay / \u5FAE\u4FE1\u652F\u4ED8", enabled: false, instructions: "Configure your verified WeChat Pay account and merchant-issued QR." },
      { id: "unionpay", name: "UnionPay / \u94F6\u8054", enabled: false, instructions: "Configure your verified UnionPay merchant account and bank-issued QR." },
      { id: "bank_transfer", name: "Bank Transfer / \u94F6\u884C\u8F6C\u8D26", enabled: false, instructions: "Configure your verified Chinese bank account." }
    ]
  },
  global: {
    methods: [
      {
        id: "cash",
        name: "Cash",
        enabled: true,
        instructions: "Cash settlement at shop desk counter"
      },
      {
        id: "bank_transfer",
        name: "Bank Transfer",
        enabled: false,
        instructions: "Configure your verified payment account and bank-issued QR before enabling."
      },
      {
        id: "card",
        name: "Credit/Debit Card",
        enabled: false,
        instructions: "Configure your verified payment account and bank-issued QR before enabling."
      },
      {
        id: "paypal",
        name: "PayPal",
        enabled: false,
        instructions: "Configure your verified payment account and bank-issued QR before enabling."
      },
      {
        id: "other",
        name: "Other",
        enabled: false,
        instructions: "Configure your verified payment account and bank-issued QR before enabling."
      }
    ]
  }
};
var demoAccounts = {
  "thailand": {
    "bank_transfer": [
      "FixFlow Mobile Services",
      "123-4-56789-0"
    ],
    "promptpay": [
      "FixFlow Mobile Solution Co., Ltd.",
      "0891234567"
    ],
    "kplus": [
      "FixFlow Mobile Solution",
      "045-2-98765-4"
    ],
    "scb_easy": [
      "FixFlow Mobile Solution",
      "168-2-34567-8"
    ],
    "truemoney": [
      "FixFlow Shop",
      "089-123-4567"
    ],
    "rabbit_line_pay": [
      "FixFlow Official",
      "LINE-FIXFLOW-PAY"
    ],
    "shopeepay": [
      "FixFlow Service Store",
      "SPAY-0891234567"
    ]
  },
  "myanmar": {
    "kbz_pay": [
      "Hacked Shop",
      "09256060722"
    ],
    "wave_pay": [
      "FixFlow Mobile",
      "09790123456"
    ],
    "aya_pay": [
      "FixFlow Service",
      "09790123456"
    ],
    "cb_pay": [
      "FixFlow Service",
      "09790123456"
    ],
    "bank_transfer": [
      "FixFlow Mobile Lab",
      "20010199928371"
    ]
  },
  "global": {
    "bank_transfer": [
      "FixFlow Technologies Inc.",
      "US9820192831092"
    ],
    "paypal": [
      "billing@fixflowlab.com",
      ""
    ]
  }
};
function removeDemoPaymentDetails(profile, method) {
  const sample = demoAccounts[profile]?.[method.id];
  if (!sample || method.qr_code || (method.account_name || "") !== sample[0] || (method.account_number || "") !== sample[1]) return method;
  const { account_name, account_number, bank_name, ...rest } = method;
  return { ...rest, enabled: false, instructions: "Configure your verified payment account and bank-issued QR before enabling." };
}

// src/server/db.ts
var import_fs = __toESM(require("fs"), 1);
var import_path = __toESM(require("path"), 1);
var import_node_crypto3 = require("node:crypto");
var DB_PATH = import_path.default.resolve(process.env.FIXFLOW_DATA_DIR || import_path.default.resolve(process.cwd(), "data"), "db.json");
var initialSeed = {
  licenses_registry: [
    {
      id: "LIC-REG-001",
      license_key: "PAID-PRO-2026-365D",
      plan: "PAID",
      license_name: "FixFlow Professional Phone Service System",
      days: 365,
      status: "ACTIVE",
      created_at: "2026-01-01T00:00:00Z",
      created_by: "system"
    },
    {
      id: "LIC-REG-002",
      license_key: "PAID-ENTERPRISE-LIFETIME",
      plan: "PAID",
      license_name: "FixFlow Enterprise Phone Service System",
      days: 3650,
      status: "ACTIVE",
      created_at: "2026-01-01T00:00:00Z",
      created_by: "system"
    }
  ],
  users: [
    {
      id: "USR-TECH-001",
      username: "kyawzin",
      full_name: "Kyaw Zin Win",
      role: "technician",
      technician_id: "TECH-001",
      created_at: "2026-08-01T09:00:00Z"
    },
    {
      id: "USR-TECH-002",
      username: "somchai",
      full_name: "Somchai Prasert",
      role: "technician",
      technician_id: "TECH-002",
      created_at: "2026-08-02T10:00:00Z"
    },
    {
      id: "USR-TECH-003",
      username: "aungko",
      full_name: "Aung Ko Min",
      role: "technician",
      technician_id: "TECH-003",
      created_at: "2026-08-05T11:00:00Z"
    },
    {
      id: "USR-TECH-004",
      username: "thiri",
      full_name: "Thiri Htun",
      role: "technician",
      technician_id: "TECH-004",
      created_at: "2026-08-10T14:00:00Z"
    }
  ],
  technicians: [
    {
      id: "TECH-001",
      full_name: "Kyaw Zin Win",
      username: "kyawzin",
      phone: "+95 9 444 888 111",
      email: "kyawzin@fixflowlab.com",
      address: "Bay 1 - Micro-soldering Station, Yangon Lab",
      status: "active",
      level: "Senior",
      specialization: ["Motherboard Micro-soldering", "Power IC", "Face ID"],
      created_at: "2026-08-01T09:00:00Z"
    },
    {
      id: "TECH-002",
      full_name: "Somchai Prasert",
      username: "somchai",
      phone: "+66 81 234 5678",
      email: "somchai@fixflowlab.com",
      address: "Bay 2 - Screen Lamination & Glass Lab",
      status: "active",
      level: "Senior",
      specialization: ["OLED Lamination", "Touch Digitizer", "iPad Glass"],
      created_at: "2026-08-02T10:00:00Z"
    },
    {
      id: "TECH-003",
      full_name: "Aung Ko Min",
      username: "aungko",
      phone: "+95 9 555 123 999",
      email: "aungko@fixflowlab.com",
      address: "Bay 3 - Mac & Logic Board Desk",
      status: "active",
      level: "Junior",
      specialization: ["MacBook Logic Board", "Power Rail Short", "Liquid Damage"],
      created_at: "2026-08-05T11:00:00Z"
    },
    {
      id: "TECH-004",
      full_name: "Thiri Htun",
      username: "thiri",
      phone: "+95 9 777 222 333",
      email: "thiri@fixflowlab.com",
      address: "Bay 4 - Hardware Diagnostics & Intake",
      status: "active",
      level: "Junior",
      specialization: ["Battery Diagnostics", "Charging Ports", "Firmware Flash"],
      created_at: "2026-08-10T14:00:00Z"
    }
  ],
  customers: [
    {
      id: "CUST-001",
      name: "Ko Aung",
      phone: "+95 9 250 111 222",
      email: "koaung@gmail.com",
      address: "Sanchaung Township, Yangon",
      created_at: "2026-08-14T09:30:00Z"
    },
    {
      id: "CUST-002",
      name: "Anong Srichan",
      phone: "+66 89 876 5432",
      email: "anong.s@outlook.com",
      address: "Bang Rak, Bangkok",
      created_at: "2026-09-02T11:15:00Z"
    },
    {
      id: "CUST-003",
      name: "Htet Lin Aung",
      phone: "+95 9 421 999 888",
      email: "htet.lin@gmail.com",
      address: "Kamayut Township, Yangon",
      created_at: "2026-09-18T14:00:00Z"
    },
    {
      id: "CUST-004",
      name: "Marcus Vance",
      phone: "+1 415 555 0192",
      email: "m.vance@techstudio.io",
      address: "Bahan Diplomatic Zone, Yangon",
      created_at: "2026-09-25T16:20:00Z"
    },
    {
      id: "CUST-005",
      name: "Nang Kham Hlaing",
      phone: "+95 9 780 444 333",
      email: "nangkham@gmail.com",
      address: "Mayangone Township, Yangon",
      created_at: "2026-10-02T10:45:00Z"
    }
  ],
  devices: [
    {
      id: "DEV-001",
      brand: "Apple",
      model: "iPhone 13",
      category: "smartphone",
      serial_or_imei: "359482019482019",
      customer_id: "CUST-001",
      condition_notes: "Phone does not boot. Housing in good condition.",
      created_at: "2026-08-14T09:30:00Z"
    },
    {
      id: "DEV-002",
      brand: "Samsung",
      model: "Galaxy S24 Ultra",
      category: "smartphone",
      serial_or_imei: "990012847162940",
      customer_id: "CUST-002",
      condition_notes: "Dropped into water. Power IC shorted.",
      created_at: "2026-09-02T11:15:00Z"
    },
    {
      id: "DEV-003",
      brand: "Apple",
      model: 'MacBook Pro 16" (M2 Max)',
      category: "laptop",
      serial_or_imei: "C02FK309MD6T",
      customer_id: "CUST-003",
      condition_notes: "Screen backlight glitch past 90 degrees.",
      created_at: "2026-09-18T14:00:00Z"
    },
    {
      id: "DEV-004",
      brand: "Dell",
      model: "XPS 15 9530",
      category: "laptop",
      serial_or_imei: "8H29KQ3",
      customer_id: "CUST-004",
      condition_notes: "Battery swelling trackpad up.",
      created_at: "2026-09-25T16:20:00Z"
    },
    {
      id: "DEV-005",
      brand: "Apple",
      model: 'iPad Pro 12.9" (6th Gen)',
      category: "tablet",
      serial_or_imei: "DMPZM84JNR7G",
      customer_id: "CUST-005",
      condition_notes: "USB-C pin bent inside port.",
      created_at: "2026-10-02T10:45:00Z"
    },
    {
      id: "DEV-006",
      brand: "Samsung",
      model: "Galaxy A54",
      category: "smartphone",
      serial_or_imei: "354819028471620",
      customer_id: "CUST-001",
      condition_notes: "Charging port intermittent.",
      created_at: "2026-10-04T12:00:00Z"
    },
    {
      id: "DEV-007",
      brand: "Xiaomi",
      model: "Redmi 12",
      category: "smartphone",
      serial_or_imei: "864910293847192",
      customer_id: "CUST-003",
      condition_notes: "Cracked screen glass.",
      created_at: "2026-10-05T14:00:00Z"
    }
  ],
  service_jobs: [
    {
      id: "JOB-001",
      service_number: "SRV-202610-0001",
      customer_id: "CUST-001",
      device_id: "DEV-001",
      technician_id: "TECH-001",
      // Assigned to Kyaw Zin Win
      status_id: "repairing",
      priority: "urgent",
      problem_description: "No Power, completely unresponsive to charging.",
      diagnosis: "VCC_MAIN short to ground caused by cracked ceramic decoupling capacitor near PMIC.",
      repair_notes: "Removed shorted capacitor under microscope. Cleaned solder pads and re-flowed power rail.",
      service_charge: 5e4,
      parts_cost: 0,
      total_cost: 5e4,
      amount_paid: 2e4,
      payment_status: "partial",
      payment_method: "digital_wallet",
      warranty_days: 30,
      passlock_pin: "1234",
      received_at: "2026-10-06T09:30:00Z",
      created_at: "2026-10-06T09:30:00Z",
      updated_at: "2026-10-07T14:00:00Z"
    },
    {
      id: "JOB-002",
      service_number: "SRV-202610-0002",
      customer_id: "CUST-002",
      device_id: "DEV-002",
      technician_id: "TECH-001",
      // Assigned to Kyaw Zin Win
      status_id: "waiting_parts",
      priority: "express",
      problem_description: "Dropped in swimming pool. Shuts off immediately after Samsung logo.",
      diagnosis: "Corrosion under primary Power Management IC (PMIC). Replacement IC required.",
      repair_notes: "Ultrasonic board clean completed. Ordered original PMIC chip from vendor.",
      service_charge: 65e3,
      parts_cost: 45e3,
      total_cost: 11e4,
      amount_paid: 5e4,
      payment_status: "partial",
      payment_method: "digital_wallet",
      warranty_days: 60,
      passlock_pin: "0000",
      received_at: "2026-10-05T11:00:00Z",
      created_at: "2026-10-05T11:00:00Z",
      updated_at: "2026-10-07T10:00:00Z"
    },
    {
      id: "JOB-003",
      service_number: "SRV-202610-0003",
      customer_id: "CUST-003",
      device_id: "DEV-003",
      technician_id: "TECH-003",
      // Assigned to Aung Ko Min
      status_id: "diagnosing",
      priority: "normal",
      problem_description: "Backlight turns off when display lid opened past 90 degrees.",
      diagnosis: "Dustgate stress fracture on eDP embedded display port ribbon flex.",
      repair_notes: "Inspecting with microscope to prepare micro-jumper wiring.",
      service_charge: 7e4,
      parts_cost: 3e4,
      total_cost: 1e5,
      amount_paid: 0,
      payment_status: "unpaid",
      warranty_days: 90,
      received_at: "2026-10-07T13:00:00Z",
      created_at: "2026-10-07T13:00:00Z",
      updated_at: "2026-10-07T15:30:00Z"
    },
    {
      id: "JOB-004",
      service_number: "SRV-202610-0004",
      customer_id: "CUST-004",
      device_id: "DEV-004",
      technician_id: "TECH-004",
      // Assigned to Thiri Htun
      status_id: "ready",
      priority: "urgent",
      problem_description: "Battery pouch swelling pushing up trackpad.",
      diagnosis: "Severely degraded lithium polymer cell pack. Urgent replacement needed.",
      repair_notes: "Safely extracted swollen battery. Installed genuine 86Wh Dell pack.",
      completion_notes: "System stress test passed. Thermals stable. Device ready for pickup.",
      service_charge: 35e3,
      parts_cost: 105e3,
      total_cost: 14e4,
      amount_paid: 14e4,
      payment_status: "paid",
      payment_method: "transfer",
      warranty_days: 180,
      received_at: "2026-10-04T10:00:00Z",
      completed_at: "2026-10-07T16:00:00Z",
      created_at: "2026-10-04T10:00:00Z",
      updated_at: "2026-10-07T16:00:00Z"
    },
    {
      id: "JOB-005",
      service_number: "SRV-202610-0005",
      customer_id: "CUST-005",
      device_id: "DEV-005",
      technician_id: "TECH-003",
      // Assigned to Aung Ko Min
      status_id: "completed",
      priority: "normal",
      problem_description: "USB-C charging connector loose. Only charges at certain angle.",
      diagnosis: "Damaged internal center pin block inside USB-C receptacle.",
      repair_notes: "Replaced USB-C daughterboard module with OEM component.",
      completion_notes: "Tested 30W Power Delivery and display video output. Full charging speed restored.",
      service_charge: 45e3,
      parts_cost: 5e4,
      total_cost: 95e3,
      amount_paid: 95e3,
      payment_status: "paid",
      payment_method: "cash",
      warranty_days: 90,
      received_at: "2026-10-02T11:00:00Z",
      completed_at: "2026-10-05T14:30:00Z",
      created_at: "2026-10-02T11:00:00Z",
      updated_at: "2026-10-05T14:30:00Z"
    },
    {
      id: "JOB-006",
      service_number: "SRV-202610-0006",
      customer_id: "CUST-001",
      device_id: "DEV-006",
      technician_id: "TECH-002",
      // Assigned to Somchai Prasert
      status_id: "repairing",
      priority: "normal",
      problem_description: "Intermittent charging and loose cable fit.",
      diagnosis: "USB-C flex sub-board damaged.",
      repair_notes: "Disassembled phone and replacing sub-board.",
      service_charge: 25e3,
      parts_cost: 15e3,
      total_cost: 4e4,
      amount_paid: 0,
      payment_status: "unpaid",
      warranty_days: 60,
      received_at: "2026-10-07T08:00:00Z",
      created_at: "2026-10-07T08:00:00Z",
      updated_at: "2026-10-07T11:00:00Z"
    },
    {
      id: "JOB-007",
      service_number: "SRV-202610-0007",
      customer_id: "CUST-003",
      device_id: "DEV-007",
      technician_id: "TECH-001",
      // Assigned to Kyaw Zin Win
      status_id: "ready",
      priority: "normal",
      problem_description: "Screen glass cracked, touch working.",
      diagnosis: "Outer glass separation and OCA refurbishing.",
      repair_notes: "Separated broken outer glass on heated vacuum platform. Laminated new 9H tempered glass lens.",
      completion_notes: "Screen tested, touch sensitivity 100%. Ready for customer collection.",
      service_charge: 3e4,
      parts_cost: 15e3,
      total_cost: 45e3,
      amount_paid: 45e3,
      payment_status: "paid",
      payment_method: "cash",
      warranty_days: 90,
      received_at: "2026-10-06T14:00:00Z",
      completed_at: "2026-10-07T17:00:00Z",
      created_at: "2026-10-06T14:00:00Z",
      updated_at: "2026-10-07T17:00:00Z"
    },
    {
      id: "JOB-008",
      service_number: "SRV-202610-0008",
      customer_id: "CUST-002",
      device_id: "DEV-002",
      technician_id: "TECH-001",
      // Assigned to Kyaw Zin Win
      status_id: "completed",
      priority: "normal",
      problem_description: "Rear camera lens glass scratched.",
      diagnosis: "Camera protective bezel scratch.",
      repair_notes: "Replaced sapphire glass bezel.",
      completion_notes: "Focus calibrated.",
      service_charge: 2e4,
      parts_cost: 1e4,
      total_cost: 3e4,
      amount_paid: 3e4,
      payment_status: "paid",
      payment_method: "transfer",
      warranty_days: 90,
      received_at: "2026-10-01T10:00:00Z",
      completed_at: "2026-10-03T12:00:00Z",
      delivered_at: "2026-10-04T15:00:00Z",
      created_at: "2026-10-01T10:00:00Z",
      updated_at: "2026-10-04T15:00:00Z"
    }
  ],
  service_job_parts: [
    {
      id: "PART-001",
      service_job_id: "JOB-002",
      part_name: "PMIC Power Management IC BGA Chip",
      quantity: 1,
      unit_cost: 45e3,
      total_cost: 45e3,
      warranty: "60 Days"
    },
    {
      id: "PART-002",
      service_job_id: "JOB-003",
      part_name: "Display Flex Jumper Wire & UV Mask",
      quantity: 1,
      unit_cost: 3e4,
      total_cost: 3e4,
      warranty: "90 Days"
    },
    {
      id: "PART-003",
      service_job_id: "JOB-004",
      part_name: "Dell Original 86Wh Li-Ion Battery Pack",
      quantity: 1,
      unit_cost: 105e3,
      total_cost: 105e3,
      warranty: "180 Days"
    },
    {
      id: "PART-004",
      service_job_id: "JOB-005",
      part_name: 'OEM iPad Pro 12.9" USB-C Port Module',
      quantity: 1,
      unit_cost: 5e4,
      total_cost: 5e4,
      warranty: "90 Days"
    },
    {
      id: "PART-005",
      service_job_id: "JOB-006",
      part_name: "Galaxy A54 Charging Board Flex",
      quantity: 1,
      unit_cost: 15e3,
      total_cost: 15e3,
      warranty: "60 Days"
    },
    {
      id: "PART-006",
      service_job_id: "JOB-007",
      part_name: "Redmi 12 Gorilla Glass Front Lens",
      quantity: 1,
      unit_cost: 15e3,
      total_cost: 15e3,
      warranty: "90 Days"
    }
  ],
  service_payments: [
    {
      id: "PAY-001",
      service_job_id: "JOB-001",
      payment_method: "KBZ Pay",
      amount: 2e4,
      currency_code: "MMK",
      paid_at: "2026-10-06T09:35:00Z",
      received_by: "Admin",
      notes: "Initial diagnosis advance deposit"
    },
    {
      id: "PAY-002",
      service_job_id: "JOB-002",
      payment_method: "Wave Pay",
      amount: 5e4,
      currency_code: "MMK",
      paid_at: "2026-10-05T11:15:00Z",
      received_by: "Admin",
      notes: "Parts deposit for replacement PMIC"
    },
    {
      id: "PAY-003",
      service_job_id: "JOB-004",
      payment_method: "Bank Transfer",
      amount: 14e4,
      currency_code: "MMK",
      paid_at: "2026-10-07T16:10:00Z",
      received_by: "Thiri Htun",
      notes: "Full payment settled upon battery replacement"
    },
    {
      id: "PAY-004",
      service_job_id: "JOB-005",
      payment_method: "Cash",
      amount: 95e3,
      currency_code: "MMK",
      paid_at: "2026-10-05T14:40:00Z",
      received_by: "Aung Ko Min",
      notes: "Cash collected upon delivery"
    },
    {
      id: "PAY-005",
      service_job_id: "JOB-007",
      payment_method: "Cash",
      amount: 45e3,
      currency_code: "MMK",
      paid_at: "2026-10-07T17:05:00Z",
      received_by: "Kyaw Zin Win",
      notes: "Screen refurbishment completed"
    },
    {
      id: "PAY-006",
      service_job_id: "JOB-008",
      payment_method: "Bank Transfer",
      amount: 3e4,
      currency_code: "MMK",
      paid_at: "2026-10-03T12:00:00Z",
      received_by: "Kyaw Zin Win",
      notes: "Full settlement"
    }
  ],
  security_audit: [
    {
      id: "AUD-001",
      user_id: "USR-001",
      username: "admin",
      action: "SYSTEM_BOOT",
      target_type: "system",
      target_id: "SYS-MAIN",
      details: "FixFlow system initialized with relational database tables.",
      ip_address: "127.0.0.1",
      created_at: "2026-10-08T08:00:00Z"
    },
    {
      id: "AUD-002",
      user_id: "USR-001",
      username: "admin",
      technician_id: "TECH-001",
      action: "JOB_ASSIGNMENT",
      target_type: "job",
      target_id: "JOB-001",
      details: "Assigned service job SRV-202610-0001 to technician Kyaw Zin Win (TECH-001).",
      ip_address: "127.0.0.1",
      created_at: "2026-10-06T09:30:00Z"
    },
    {
      id: "AUD-003",
      user_id: "USR-TECH-001",
      username: "kyawzin",
      technician_id: "TECH-001",
      action: "STATUS_UPDATE",
      target_type: "job",
      target_id: "JOB-001",
      details: "Technician Kyaw Zin Win changed status from Diagnosing to Repairing.",
      ip_address: "192.168.1.101",
      created_at: "2026-10-07T14:00:00Z"
    }
  ],
  income_records: [
    {
      id: "INC-202610-0001",
      date: "2026-10-08T09:00:00Z",
      reference: "REC-0912",
      service_number: "SRV-202610-0001",
      service_job_id: "JOB-001",
      customer_name: "Ko Aung",
      technician_id: "TECH-001",
      technician_name: "Kyaw Zin Win",
      description: "Phone Screen & Battery Replacement Service",
      amount: 5e4,
      currency: "MMK",
      payment_method: "cash",
      created_by: "admin",
      created_at: "2026-10-08T09:00:00Z"
    },
    {
      id: "INC-202610-0002",
      date: "2026-10-08T10:30:00Z",
      reference: "REC-0913",
      service_number: "SRV-202610-0002",
      service_job_id: "JOB-002",
      customer_name: "Daw Mya Mya",
      technician_id: "TECH-002",
      technician_name: "Aung Kyaw Thu",
      description: "Display Assembly Diagnostic & Repair",
      amount: 75e3,
      currency: "MMK",
      payment_method: "kbzpay",
      created_by: "admin",
      created_at: "2026-10-08T10:30:00Z"
    }
  ],
  expense_records: [
    {
      id: "EXP-202610-0001",
      date: "2026-10-08T08:30:00Z",
      reference: "INV-P-881",
      category: "Parts",
      description: "iPhone 13 OLED Screen Replacement Module",
      amount: 3e4,
      currency: "MMK",
      payment_method: "cash",
      created_by: "admin",
      created_at: "2026-10-08T08:30:00Z"
    },
    {
      id: "EXP-202610-0002",
      date: "2026-10-07T11:00:00Z",
      reference: "INV-T-102",
      category: "Tools",
      description: "Precision Soldering Tips and BGA Flux",
      amount: 15e3,
      currency: "MMK",
      payment_method: "cash",
      created_by: "admin",
      created_at: "2026-10-07T11:00:00Z"
    }
  ],
  settlements: [
    {
      id: "SETTLE-202610-0001",
      settlement_type: "daily",
      period_start: "2026-10-07T00:00:00Z",
      period_end: "2026-10-07T23:59:59Z",
      total_service_charges: 125e3,
      total_payments: 125e3,
      outstanding_balance: 0,
      total_income: 125e3,
      total_expense: 45e3,
      net_balance: 8e4,
      currency: "MMK",
      status: "closed",
      closed_by: "admin",
      closed_at: "2026-10-07T18:00:00Z",
      notes: "Daily bench ledger reconciled and verified by admin.",
      created_at: "2026-10-07T18:00:00Z"
    }
  ],
  login_attempts: [
    {
      id: "LOG-001",
      username: "admin",
      success: true,
      ip_address: "127.0.0.1",
      attempted_at: "2026-10-08T08:01:00Z"
    },
    {
      id: "LOG-002",
      username: "kyawzin",
      success: true,
      ip_address: "192.168.1.101",
      attempted_at: "2026-10-08T08:15:00Z"
    }
  ],
  settings: {
    shopName: "Hacked Shop",
    phone: "+95 9256060722",
    email: "shwetaythan@gmail.com",
    address: "Naypyitaw (Myanmar)",
    receiptFooterNote: "All phone repairs carry limited warranty on replaced parts and workmanship. Liquid damage diagnostics carry inspection warranty only.",
    defaultWarrantyDays: 90,
    currency: "MMK",
    currency_mode: "manual",
    language: "en",
    theme: "system",
    dateFormat: "DD MMM YYYY",
    paperSize: "80mm",
    taxPercentage: 0,
    paymentMethods: ["Cash", "Bank Transfer", "Digital Wallet"],
    paymentSettings: defaultPaymentSettings,
    license: {
      license_name: "Free Phone Service Management System",
      plan: "FREE",
      status: "ACTIVE",
      license_key: "FREE-COMMUNITY-EDITION",
      installation_id: "FIXFLOW-INST-882194",
      license_days: 30,
      expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1e3).toISOString(),
      last_verified_at: (/* @__PURE__ */ new Date()).toISOString(),
      server_url: "https://posowner.myominaung.xyz",
      owner_verified: true
    },
    telegramBot: {
      enabled: false,
      bot_token: "",
      chat_id: "",
      channel_username: "",
      notify_on_new_job: true,
      notify_on_status_change: true,
      notify_on_payment: false,
      notify_on_daily_summary: false,
      is_connected: false
    }
  }
};
var Database = class {
  constructor() {
    this.ensureDirectory();
    this.data = this.loadDatabase();
    if (this.data.users.some((user) => user.role === "admin" && Boolean(user.password))) this.data.admin_setup_complete = true;
    if (this.ensureCashierCodes()) this.saveDatabase();
  }
  ensureDirectory() {
    const dir = import_path.default.dirname(DB_PATH);
    if (!import_fs.default.existsSync(dir)) {
      import_fs.default.mkdirSync(dir, { recursive: true });
    }
  }
  loadDatabase() {
    try {
      if (import_fs.default.existsSync(DB_PATH)) {
        const fileContent = import_fs.default.readFileSync(DB_PATH, "utf-8");
        const parsed = JSON.parse(fileContent);
        const mergedSettings = {
          ...initialSeed.settings,
          ...parsed.settings || {},
          paymentSettings: {
            ...defaultPaymentSettings,
            ...parsed.settings?.paymentSettings || {},
            thailand: {
              methods: defaultPaymentSettings.thailand.methods.map((defaultMethod) => {
                const existing = parsed.settings?.paymentSettings?.thailand?.methods?.find((m) => m.id === defaultMethod.id);
                return existing ? { ...defaultMethod, ...removeDemoPaymentDetails("thailand", existing) } : defaultMethod;
              })
            },
            myanmar: {
              methods: defaultPaymentSettings.myanmar.methods.map((defaultMethod) => {
                const existing = parsed.settings?.paymentSettings?.myanmar?.methods?.find((m) => m.id === defaultMethod.id);
                return existing ? { ...defaultMethod, ...removeDemoPaymentDetails("myanmar", existing) } : defaultMethod;
              })
            },
            china: {
              methods: defaultPaymentSettings.china.methods.map((defaultMethod) => {
                const existing = parsed.settings?.paymentSettings?.china?.methods?.find((m) => m.id === defaultMethod.id);
                return existing ? { ...defaultMethod, ...existing } : { ...defaultMethod };
              })
            },
            global: {
              methods: defaultPaymentSettings.global.methods.map((defaultMethod) => {
                const existing = parsed.settings?.paymentSettings?.global?.methods?.find((m) => m.id === defaultMethod.id);
                return existing ? { ...defaultMethod, ...removeDemoPaymentDetails("global", existing) } : defaultMethod;
              })
            }
          }
        };
        mergedSettings.currency_mode = "manual";
        if (!["my", "en", "th", "zh"].includes(mergedSettings.language)) mergedSettings.language = "en";
        if (!["MMK", "USD", "THB", "CNY"].includes(mergedSettings.currency)) mergedSettings.currency = "MMK";
        return {
          ...initialSeed,
          ...parsed,
          income_records: parsed.income_records ?? [],
          expense_records: parsed.expense_records ?? [],
          settlements: parsed.settlements ?? [],
          settings: mergedSettings
        };
      }
    } catch (err) {
      throw new Error("Cannot read data/db.json; restore a valid backup before starting.", { cause: err });
    }
    this.saveDatabase(initialSeed);
    return JSON.parse(JSON.stringify(initialSeed));
  }
  saveDatabase(dataToSave) {
    try {
      const data = dataToSave || this.data;
      const temporaryPath = `${DB_PATH}.tmp`;
      import_fs.default.writeFileSync(temporaryPath, JSON.stringify(data, null, 2), "utf-8");
      import_fs.default.renameSync(temporaryPath, DB_PATH);
    } catch (err) {
      throw new Error("Database could not be saved.", { cause: err });
    }
  }
  nextNumber(key) {
    const records = this.data[key];
    const maximum = records.reduce((maximum2, record) => {
      const suffix = Number(record.id.match(/-(\d+)$/)?.[1] || 0);
      return Math.max(maximum2, suffix);
    }, 0);
    this.data.id_counters ??= {};
    const next = Math.max(maximum, this.data.id_counters[key] || 0) + 1;
    this.data.id_counters[key] = next;
    return next;
  }
  // --- Populated query helper ---
  populateJob(job) {
    const technician = this.data.technicians.find((t) => t.id === job.technician_id);
    const customer = this.data.customers.find((c) => c.id === job.customer_id);
    const device = this.data.devices.find((d) => d.id === job.device_id);
    const parts = this.data.service_job_parts.filter((p) => p.service_job_id === job.id);
    const payments = this.getPaymentsByJobId(job.id);
    return {
      ...job,
      technician: technician || void 0,
      customer: customer || void 0,
      device: device || void 0,
      parts_used: parts,
      payments
    };
  }
  // Notifications are recipient-specific and share the event's database commit.
  addNotification(type, job, recipientIds, details = {}) {
    this.data.notifications ??= [];
    const recipients = new Set(recipientIds);
    for (const userId of recipients) {
      this.data.notifications.unshift({
        ...details,
        id: `NTF-${(0, import_node_crypto3.randomUUID)()}`,
        user_id: userId,
        type,
        service_job_id: job.id,
        service_number: job.service_number,
        created_at: (/* @__PURE__ */ new Date()).toISOString()
      });
    }
    const counts = /* @__PURE__ */ new Map();
    this.data.notifications = this.data.notifications.filter((notification) => {
      const count = (counts.get(notification.user_id) || 0) + 1;
      counts.set(notification.user_id, count);
      return count <= 250;
    });
  }
  adminRecipients() {
    return this.data.users.filter((user) => user.role === "admin").map((user) => user.id);
  }
  cashierRecipients() {
    return this.data.users.filter((user) => user.role === "cashier" && user.active !== false).map((user) => user.id);
  }
  technicianRecipients(technicianId) {
    return this.data.users.filter((user) => user.role === "technician" && user.technician_id === technicianId).map((user) => user.id);
  }
  getNotifications(userId) {
    return (this.data.notifications || []).filter((notification) => notification.user_id === userId && !notification.dismissed_at);
  }
  markNotificationRead(id, userId) {
    const notification = this.getNotifications(userId).find((notification2) => notification2.id === id);
    if (!notification) return null;
    if (!notification.read_at) {
      notification.read_at = (/* @__PURE__ */ new Date()).toISOString();
      this.saveDatabase();
    }
    return notification;
  }
  markAllNotificationsRead(userId) {
    const unread = this.getNotifications(userId).filter((notification) => !notification.read_at);
    if (unread.length) {
      const timestamp = (/* @__PURE__ */ new Date()).toISOString();
      unread.forEach((notification) => {
        notification.read_at = timestamp;
      });
      this.saveDatabase();
    }
    return unread.length;
  }
  dismissNotification(id, userId) {
    const notification = this.getNotifications(userId).find((notification2) => notification2.id === id);
    if (!notification) return false;
    notification.dismissed_at = (/* @__PURE__ */ new Date()).toISOString();
    this.saveDatabase();
    return true;
  }
  clearReadNotifications(userId) {
    const read = this.getNotifications(userId).filter((notification) => notification.read_at);
    if (read.length) {
      const timestamp = (/* @__PURE__ */ new Date()).toISOString();
      read.forEach((notification) => {
        notification.dismissed_at = timestamp;
      });
      this.saveDatabase();
    }
    return read.length;
  }
  // --- Technicians ---
  getTechnicians() {
    return this.data.technicians;
  }
  getTechnicianById(id) {
    return this.data.technicians.find((t) => t.id === id);
  }
  createTechnician(tech) {
    const nextNum = this.nextNumber("technicians");
    const newId = `TECH-${String(nextNum).padStart(3, "0")}`;
    const newTech = {
      ...tech,
      id: newId,
      status: tech.status || "active",
      created_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    this.data.technicians.push(newTech);
    const newUser = {
      id: `USR-${newId}`,
      username: tech.username,
      full_name: tech.full_name,
      role: "technician",
      phone: tech.phone,
      email: tech.email,
      technician_id: newId,
      created_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    this.data.users.push(newUser);
    this.saveDatabase();
    return newTech;
  }
  updateTechnician(id, updates) {
    const index = this.data.technicians.findIndex((t) => t.id === id);
    if (index === -1) return null;
    this.data.technicians[index] = {
      ...this.data.technicians[index],
      ...updates,
      id,
      created_at: this.data.technicians[index].created_at
    };
    const userIndex = this.data.users.findIndex((u) => u.technician_id === id);
    if (userIndex !== -1) {
      if (updates.full_name) this.data.users[userIndex].full_name = updates.full_name;
      if (updates.username) this.data.users[userIndex].username = updates.username;
    }
    this.saveDatabase();
    return this.data.technicians[index];
  }
  deleteTechnician(id) {
    const fallbackTech = this.data.technicians.find((t) => t.id !== id)?.id || "TECH-001";
    if (this.data.service_jobs) {
      this.data.service_jobs.forEach((job) => {
        if (job.technician_id === id) {
          job.technician_id = fallbackTech;
        }
      });
    }
    this.data.technicians = this.data.technicians.filter((t) => t.id !== id);
    const removedUserIds = new Set(this.data.users.filter((user) => user.technician_id === id).map((user) => user.id));
    this.data.notifications = (this.data.notifications || []).filter((notification) => !removedUserIds.has(notification.user_id));
    this.data.users = this.data.users.filter((u) => u.technician_id !== id);
    this.saveDatabase();
    return true;
  }
  // --- Users & Auth ---
  getUsers() {
    return this.data.users;
  }
  nextCashierCode() {
    this.data.id_counters ??= {};
    const maximum = this.data.users.reduce((value, user) => {
      const number = typeof user.staff_code === "string" ? Number(user.staff_code.match(/^CASH-(\d+)$/)?.[1] || 0) : 0;
      return Math.max(value, Number.isSafeInteger(number) ? number : 0);
    }, this.data.id_counters.cashier_codes || 0);
    this.data.id_counters.cashier_codes = maximum + 1;
    return `CASH-${String(maximum + 1).padStart(4, "0")}`;
  }
  ensureCashierCodes() {
    const seen = /* @__PURE__ */ new Set();
    let changed = false;
    for (const user of this.data.users) {
      if (user.role !== "cashier") continue;
      if (typeof user.staff_code !== "string" || !/^CASH-\d{4,}$/.test(user.staff_code) || !Number.isSafeInteger(Number(user.staff_code.slice(5))) || seen.has(user.staff_code)) {
        user.staff_code = this.nextCashierCode();
        changed = true;
      }
      seen.add(user.staff_code);
    }
    return changed;
  }
  isAdminSetupComplete() {
    return this.data.admin_setup_complete === true || this.data.users.some((user) => user.role === "admin" && Boolean(user.password));
  }
  setupFirstAdmin(input) {
    if (this.isAdminSetupComplete()) throw new Error("Admin registration is already completed.");
    const before = structuredClone(this.data);
    try {
      this.data.users = this.data.users.filter((user2) => !(user2.role === "admin" && user2.username === "admin" && !user2.password));
      if (this.data.users.some((user2) => user2.username.toLowerCase() === input.username.toLowerCase())) throw new Error("Username is already in use.");
      const user = { ...input, id: `USR-ADMIN-${(0, import_node_crypto3.randomUUID)()}`, role: "admin", active: true, created_at: (/* @__PURE__ */ new Date()).toISOString() };
      this.data.users.push(user);
      this.data.admin_setup_complete = true;
      this.saveDatabase();
      return user;
    } catch (error) {
      this.data = before;
      throw error;
    }
  }
  createAdmin(input) {
    const user = { ...input, id: `USR-ADMIN-${(0, import_node_crypto3.randomUUID)()}`, role: "admin", active: true, created_at: (/* @__PURE__ */ new Date()).toISOString() };
    this.data.users.push(user);
    this.saveDatabase();
    return user;
  }
  createCashier(input) {
    const user = { ...input, staff_code: this.nextCashierCode(), id: `USR-CASH-${(0, import_node_crypto3.randomUUID)()}`, username: input.username, full_name: input.full_name, password: input.password, role: "cashier", active: true, created_at: (/* @__PURE__ */ new Date()).toISOString() };
    this.data.users.push(user);
    this.saveDatabase();
    return user;
  }
  updateCashier(id, updates) {
    const user = this.data.users.find((u) => u.id === id && u.role === "cashier");
    if (!user) return null;
    Object.assign(user, updates);
    this.saveDatabase();
    return user;
  }
  deleteCashier(id) {
    const user = this.data.users.find((u) => u.id === id && u.role === "cashier");
    if (!user) return false;
    this.data.users = this.data.users.filter((u) => u.id !== id);
    this.data.notifications = (this.data.notifications || []).filter((n) => n.user_id !== id);
    this.saveDatabase();
    return true;
  }
  getUserByUsername(username) {
    return this.data.users.find(
      (u) => u.username.toLowerCase() === username.toLowerCase()
    );
  }
  resetPasswordTransaction(userId, password, ip = "local") {
    const previous = structuredClone(this.data);
    const user = this.data.users.find((u) => u.id === userId);
    if (!user) throw new Error("Unknown account.");
    try {
      user.password = password;
      const technician = this.data.technicians.find((t) => t.id === user.technician_id);
      if (technician) technician.password = password;
      this.data.security_audit.unshift({ id: `AUD-${String(this.nextNumber("security_audit")).padStart(4, "0")}`, user_id: user.id, username: user.username, action: "PASSWORD_RECOVERED", target_type: "auth", target_id: user.id, details: "Password recovered with this PC\u2019s key; recovery key rotated.", ip_address: ip, created_at: (/* @__PURE__ */ new Date()).toISOString() });
      this.saveDatabase();
    } catch (error) {
      this.data = previous;
      throw error;
    }
    return () => {
      this.data = previous;
      this.saveDatabase();
    };
  }
  updatePassword(userId, newPass) {
    const user = this.data.users.find((u) => u.id === userId);
    if (!user) return false;
    if (user.technician_id) {
      const tech = this.data.technicians.find((t) => t.id === user.technician_id);
      if (tech) {
        tech.password = newPass;
      }
    }
    user.password = newPass;
    this.saveDatabase();
    return true;
  }
  updateProfile(userId, updates) {
    const user = this.data.users.find((u) => u.id === userId);
    if (!user) return null;
    if (user.role === "cashier" && updates.username && updates.username !== user.username) {
      for (const payment of this.data.service_payments) if (!payment.cashier_id && payment.created_by === user.username) payment.cashier_id = user.id;
    }
    Object.assign(user, updates);
    if (user.technician_id) {
      const tech = this.data.technicians.find((t) => t.id === user.technician_id);
      if (tech) {
        if (updates.full_name) tech.full_name = updates.full_name;
        if (updates.username) tech.username = updates.username;
        if (updates.email !== void 0) tech.email = updates.email;
        if (updates.phone !== void 0) tech.phone = updates.phone;
        if (updates.profile_photo !== void 0) tech.profile_photo = updates.profile_photo;
      }
    }
    this.saveDatabase();
    return user;
  }
  recordLoginAttempt(username, success, ip) {
    const attempt = {
      id: `LOG-${(0, import_node_crypto3.randomUUID)()}`,
      username,
      success,
      ip_address: ip,
      attempted_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    this.data.login_attempts.push(attempt);
    this.saveDatabase();
  }
  auditTransaction(audit) {
    const previous = structuredClone(this.data);
    try {
      this.recordAudit(audit);
    } catch (error) {
      this.data = previous;
      throw error;
    }
    return () => {
      this.data = previous;
      this.saveDatabase();
    };
  }
  recordAudit(audit) {
    const entry = {
      ...audit,
      id: `AUD-${(0, import_node_crypto3.randomUUID)()}`,
      created_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    this.data.security_audit.unshift(entry);
    this.saveDatabase();
  }
  getAuditTrail() {
    return this.data.security_audit;
  }
  // --- Service Jobs ---
  getJobs() {
    return this.data.service_jobs.map((j) => this.populateJob(j));
  }
  getJobById(id) {
    const job = this.data.service_jobs.find((j) => j.id === id);
    return job ? this.populateJob(job) : void 0;
  }
  createJob(jobData) {
    const nextNum = this.nextNumber("service_jobs");
    const yearMonth = (/* @__PURE__ */ new Date()).toISOString().slice(0, 7).replace("-", "");
    const service_number = `SRV-${yearMonth}-${String(nextNum).padStart(4, "0")}`;
    const id = `JOB-${String(nextNum).padStart(3, "0")}`;
    const newJob = {
      ...jobData,
      id,
      service_number,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    this.data.service_jobs.unshift(newJob);
    if (newJob.amount_paid > 0) {
      const payNum = this.nextNumber("service_payments");
      const payId = `PAY-${yearMonth}-${String(payNum).padStart(4, "0")}`;
      this.data.service_payments.unshift({
        id: payId,
        service_job_id: id,
        payment_method: newJob.payment_method || "Cash",
        amount: newJob.amount_paid,
        currency_code: newJob.currency_code || this.data.settings.currency || "MMK",
        paid_at: (/* @__PURE__ */ new Date()).toISOString(),
        received_by: newJob.intake_received_by || "Admin",
        created_by: newJob.intake_username,
        cashier_id: newJob.intake_cashier_id,
        notes: "Initial intake advance deposit"
      });
    }
    if (jobData.parts_used && jobData.parts_used.length > 0) {
      jobData.parts_used.forEach((part) => {
        this.data.service_job_parts.push({
          ...part,
          id: part.id || `PART-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          service_job_id: id
        });
      });
    }
    this.addNotification("new_job", newJob, [...this.adminRecipients(), ...this.cashierRecipients()]);
    this.addNotification("assigned_job", newJob, this.technicianRecipients(newJob.technician_id));
    if (newJob.amount_paid > 0) {
      this.addNotification("payment_received", newJob, [...this.adminRecipients(), ...newJob.intake_cashier_id ? [newJob.intake_cashier_id] : []], {
        amount: newJob.amount_paid,
        currency_code: newJob.currency_code || this.data.settings.currency
      });
    }
    this.saveDatabase();
    return this.populateJob(newJob);
  }
  updateJob(id, updates) {
    const index = this.data.service_jobs.findIndex((j) => j.id === id);
    if (index === -1) return null;
    const previousJob = { ...this.data.service_jobs[index] };
    if (updates.parts_used) {
      this.data.service_job_parts = this.data.service_job_parts.filter(
        (p) => p.service_job_id !== id
      );
      updates.parts_used.forEach((part) => {
        this.data.service_job_parts.push({
          ...part,
          id: part.id || `PART-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          service_job_id: id
        });
      });
    }
    const { parts_used, technician, customer, device, payments, ...jobFields } = updates;
    this.data.service_jobs[index] = {
      ...this.data.service_jobs[index],
      ...jobFields,
      id,
      service_number: this.data.service_jobs[index].service_number,
      created_at: this.data.service_jobs[index].created_at,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    this.recalcJobPayments(id);
    const updatedJob = this.data.service_jobs[index];
    if (updatedJob.technician_id !== previousJob.technician_id) {
      this.addNotification("reassigned_job", updatedJob, this.adminRecipients());
      this.addNotification("assigned_job", updatedJob, this.technicianRecipients(updatedJob.technician_id));
    }
    if (updatedJob.status_id !== previousJob.status_id) {
      this.addNotification(
        "status_change",
        updatedJob,
        [...this.adminRecipients(), ...this.technicianRecipients(updatedJob.technician_id), ...this.cashierRecipients()],
        { status_id: updatedJob.status_id, previous_status: previousJob.status_id }
      );
    }
    this.saveDatabase();
    return this.populateJob(this.data.service_jobs[index]);
  }
  deleteJob(id) {
    const initialLength = this.data.service_jobs.length;
    this.data.service_jobs = this.data.service_jobs.filter((j) => j.id !== id);
    this.data.service_job_parts = this.data.service_job_parts.filter((p) => p.service_job_id !== id);
    this.data.service_payments = this.data.service_payments.filter((p) => p.service_job_id !== id);
    this.saveDatabase();
    return this.data.service_jobs.length < initialLength;
  }
  // --- Payments ---
  recalcJobPayments(jobId) {
    const jobIndex = this.data.service_jobs.findIndex((j) => j.id === jobId);
    if (jobIndex === -1) return;
    const job = this.data.service_jobs[jobIndex];
    const activePayments = this.data.service_payments.filter(
      (p) => p.service_job_id === job.id && !p.is_deleted
    );
    const totalPaid = activePayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
    const totalCost = job.total_cost || job.service_charge + job.parts_cost;
    this.data.service_jobs[jobIndex] = {
      ...job,
      amount_paid: totalPaid,
      payment_status: totalPaid >= totalCost && totalCost > 0 ? "paid" : totalPaid > 0 ? "partial" : "unpaid",
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    };
  }
  getPayments(includeDeleted = false) {
    const list = includeDeleted ? this.data.service_payments : this.data.service_payments.filter((p) => !p.is_deleted);
    return list.map((p) => {
      const job = this.data.service_jobs.find((j) => j.id === p.service_job_id);
      const cust = job ? this.data.customers.find((c) => c.id === job.customer_id) : void 0;
      const tech = job ? this.data.technicians.find((t) => t.id === job.technician_id) : void 0;
      return {
        ...p,
        service_number: job?.service_number,
        customer_name: cust?.name,
        technician_id: job?.technician_id,
        technician_name: tech?.full_name
        // Must be the related Service Job technician
      };
    });
  }
  getPaymentById(id) {
    const p = this.data.service_payments.find((x) => x.id === id);
    if (!p) return void 0;
    const job = this.data.service_jobs.find((j) => j.id === p.service_job_id);
    const cust = job ? this.data.customers.find((c) => c.id === job.customer_id) : void 0;
    const tech = job ? this.data.technicians.find((t) => t.id === job.technician_id) : void 0;
    return {
      ...p,
      service_number: job?.service_number,
      customer_name: cust?.name,
      technician_id: job?.technician_id,
      technician_name: tech?.full_name
    };
  }
  getPaymentsByJobId(jobId, includeDeleted = false) {
    return this.data.service_payments.filter((p) => p.service_job_id === jobId && (includeDeleted || !p.is_deleted)).map((p) => {
      const job = this.data.service_jobs.find((j) => j.id === p.service_job_id);
      const cust = job ? this.data.customers.find((c) => c.id === job.customer_id) : void 0;
      const tech = job ? this.data.technicians.find((t) => t.id === job.technician_id) : void 0;
      return {
        ...p,
        service_number: job?.service_number,
        customer_name: cust?.name,
        technician_id: job?.technician_id,
        technician_name: tech?.full_name
      };
    });
  }
  createPayment(payment) {
    const nextNum = this.nextNumber("service_payments");
    const yearMonth = (/* @__PURE__ */ new Date()).toISOString().slice(0, 7).replace("-", "");
    const id = `PAY-${yearMonth}-${String(nextNum).padStart(4, "0")}`;
    const newPayment = {
      ...payment,
      id,
      paid_at: payment.paid_at || (/* @__PURE__ */ new Date()).toISOString(),
      is_deleted: false,
      status: "completed"
    };
    this.data.service_payments.unshift(newPayment);
    this.recalcJobPayments(payment.service_job_id);
    const notificationJob = this.data.service_jobs.find((job2) => job2.id === payment.service_job_id);
    if (notificationJob) this.addNotification("payment_received", notificationJob, [...this.adminRecipients(), ...newPayment.cashier_id ? [newPayment.cashier_id] : []], {
      amount: newPayment.amount,
      currency_code: newPayment.currency_code
    });
    this.saveDatabase();
    const job = this.data.service_jobs.find((j) => j.id === payment.service_job_id);
    const cust = job ? this.data.customers.find((c) => c.id === job.customer_id) : void 0;
    const tech = job ? this.data.technicians.find((t) => t.id === job.technician_id) : void 0;
    return {
      ...newPayment,
      service_number: job?.service_number,
      customer_name: cust?.name,
      technician_id: job?.technician_id,
      technician_name: tech?.full_name
    };
  }
  updatePayment(id, updates, editedBy, editReason) {
    const index = this.data.service_payments.findIndex((p) => p.id === id);
    if (index === -1) return null;
    const oldPayment = { ...this.data.service_payments[index] };
    const oldJobId = oldPayment.service_job_id;
    this.data.service_payments[index] = {
      ...oldPayment,
      ...updates,
      updated_by: editedBy,
      updated_at: (/* @__PURE__ */ new Date()).toISOString(),
      edit_reason: editReason || updates.edit_reason
    };
    this.recalcJobPayments(this.data.service_payments[index].service_job_id);
    if (updates.service_job_id && updates.service_job_id !== oldJobId) {
      this.recalcJobPayments(oldJobId);
    }
    this.saveDatabase();
    return this.getPaymentById(id) || null;
  }
  deletePayment(id, deletedBy, deleteReason) {
    const index = this.data.service_payments.findIndex((p) => p.id === id);
    if (index === -1) return null;
    this.data.service_payments[index] = {
      ...this.data.service_payments[index],
      is_deleted: true,
      deleted_at: (/* @__PURE__ */ new Date()).toISOString(),
      deleted_by: deletedBy,
      delete_reason: deleteReason,
      status: "deleted"
    };
    this.recalcJobPayments(this.data.service_payments[index].service_job_id);
    this.saveDatabase();
    return this.getPaymentById(id) || null;
  }
  // --- Income & Expense Accounting ---
  getIncome(includeDeleted = false) {
    const list = includeDeleted ? this.data.income_records || [] : (this.data.income_records || []).filter((r) => !r.is_deleted);
    return list.map((inc) => {
      let techName = inc.technician_name;
      if (inc.technician_id && !techName) {
        techName = this.data.technicians.find((t) => t.id === inc.technician_id)?.full_name;
      }
      return { ...inc, technician_name: techName };
    });
  }
  createIncome(data) {
    if (!this.data.income_records) this.data.income_records = [];
    const nextNum = this.nextNumber("income_records");
    const yearMonth = (/* @__PURE__ */ new Date()).toISOString().slice(0, 7).replace("-", "");
    const id = `INC-${yearMonth}-${String(nextNum).padStart(4, "0")}`;
    const newRecord = {
      ...data,
      id,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      is_deleted: false
    };
    this.data.income_records.unshift(newRecord);
    this.saveDatabase();
    return newRecord;
  }
  updateIncome(id, updates) {
    if (!this.data.income_records) return null;
    const index = this.data.income_records.findIndex((r) => r.id === id);
    if (index === -1) return null;
    this.data.income_records[index] = {
      ...this.data.income_records[index],
      ...updates
    };
    this.saveDatabase();
    return this.data.income_records[index];
  }
  deleteIncome(id, deletedBy) {
    if (!this.data.income_records) return false;
    const index = this.data.income_records.findIndex((r) => r.id === id);
    if (index === -1) return false;
    this.data.income_records[index] = {
      ...this.data.income_records[index],
      is_deleted: true,
      deleted_at: (/* @__PURE__ */ new Date()).toISOString(),
      deleted_by: deletedBy
    };
    this.saveDatabase();
    return true;
  }
  getExpenses(includeDeleted = false) {
    return includeDeleted ? this.data.expense_records || [] : (this.data.expense_records || []).filter((r) => !r.is_deleted);
  }
  createExpense(data) {
    if (!this.data.expense_records) this.data.expense_records = [];
    const nextNum = this.nextNumber("expense_records");
    const yearMonth = (/* @__PURE__ */ new Date()).toISOString().slice(0, 7).replace("-", "");
    const id = `EXP-${yearMonth}-${String(nextNum).padStart(4, "0")}`;
    const newRecord = {
      ...data,
      id,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      is_deleted: false
    };
    this.data.expense_records.unshift(newRecord);
    this.saveDatabase();
    return newRecord;
  }
  updateExpense(id, updates) {
    if (!this.data.expense_records) return null;
    const index = this.data.expense_records.findIndex((r) => r.id === id);
    if (index === -1) return null;
    this.data.expense_records[index] = {
      ...this.data.expense_records[index],
      ...updates
    };
    this.saveDatabase();
    return this.data.expense_records[index];
  }
  deleteExpense(id, deletedBy) {
    if (!this.data.expense_records) return false;
    const index = this.data.expense_records.findIndex((r) => r.id === id);
    if (index === -1) return false;
    this.data.expense_records[index] = {
      ...this.data.expense_records[index],
      is_deleted: true,
      deleted_at: (/* @__PURE__ */ new Date()).toISOString(),
      deleted_by: deletedBy
    };
    this.saveDatabase();
    return true;
  }
  // --- Settlements ---
  getSettlements() {
    return this.data.settlements || [];
  }
  createSettlement(data) {
    if (!this.data.settlements) this.data.settlements = [];
    const nextNum = this.nextNumber("settlements");
    const yearMonth = (/* @__PURE__ */ new Date()).toISOString().slice(0, 7).replace("-", "");
    const id = `SETTLE-${yearMonth}-${String(nextNum).padStart(4, "0")}`;
    const newRecord = {
      ...data,
      status: data.status || "open",
      id,
      created_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    this.data.settlements.unshift(newRecord);
    this.saveDatabase();
    return newRecord;
  }
  closeSettlement(id, closedBy) {
    if (!this.data.settlements) return null;
    const index = this.data.settlements.findIndex((r) => r.id === id);
    if (index === -1) return null;
    this.data.settlements[index] = {
      ...this.data.settlements[index],
      status: "closed",
      closed_by: closedBy,
      closed_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    this.saveDatabase();
    return this.data.settlements[index];
  }
  // --- Database Backup & Restore ---
  createBackupSnapshot() {
    const snapshot = JSON.parse(JSON.stringify(this.data));
    const timestamp = (/* @__PURE__ */ new Date()).toISOString();
    const filename = `fixflow_backup_${timestamp.replace(/[:.]/g, "-")}.json`;
    const jsonStr = JSON.stringify(snapshot, null, 2);
    const sizeBytes = Buffer.byteLength(jsonStr, "utf-8");
    const metadata = {
      id: `BAK-${Date.now()}`,
      filename,
      created_at: timestamp,
      size_bytes: sizeBytes,
      item_counts: {
        customers: (this.data.customers || []).length,
        devices: (this.data.devices || []).length,
        technicians: (this.data.technicians || []).length,
        service_jobs: (this.data.service_jobs || []).length,
        service_job_parts: (this.data.service_job_parts || []).length,
        service_payments: (this.data.service_payments || []).length,
        income_records: (this.data.income_records || []).length,
        expense_records: (this.data.expense_records || []).length,
        settlements: (this.data.settlements || []).length,
        security_audit: (this.data.security_audit || []).length
      },
      status: "valid"
    };
    return {
      metadata,
      data: snapshot
    };
  }
  clearDemoData() {
    this.data.service_jobs = [];
    this.data.service_job_parts = [];
    this.data.service_payments = [];
    this.data.customers = [];
    this.data.devices = [];
    this.data.technicians = [];
    this.data.income_records = [];
    this.data.expense_records = [];
    this.data.security_audit = [];
    this.data.notifications = [];
    this.data.settlements = [];
    this.data.users = this.data.users.filter((u) => u.role === "admin");
    this.saveDatabase();
  }
  restoreBackupSnapshot(backupData, restoredBy) {
    if (!backupData || typeof backupData !== "object") {
      return { success: false, error: "Invalid backup file: Not a valid JSON object." };
    }
    const requiredKeys = ["users", "technicians", "customers", "devices", "service_jobs", "settings"];
    for (const key of requiredKeys) {
      if (!(key in backupData)) {
        return { success: false, error: `Incompatible backup file: missing required key "${key}".` };
      }
    }
    const arrayKeys = [
      "users",
      "technicians",
      "customers",
      "devices",
      "service_jobs",
      "service_job_parts",
      "service_payments",
      "income_records",
      "expense_records",
      "settlements",
      "security_audit",
      "login_attempts",
      "licenses_registry",
      "notifications"
    ];
    for (const key of arrayKeys) {
      const records = backupData[key];
      if (records === void 0 && !requiredKeys.includes(key)) continue;
      if (!Array.isArray(records) || records.some((record) => !record || typeof record !== "object" || typeof record.id !== "string" || !record.id) || new Set(records.map((record) => record.id)).size !== records.length) {
        return { success: false, error: `Invalid backup collection: ${key}. Expected records with unique IDs.` };
      }
    }
    if (backupData.users.some((user) => typeof user.username !== "string" || !user.username || !["admin", "technician", "cashier"].includes(user.role))) {
      return { success: false, error: "Invalid backup user account." };
    }
    const foreignKeys = [
      ["devices", "customer_id", "customers"],
      ["service_jobs", "customer_id", "customers"],
      ["service_jobs", "device_id", "devices"],
      ["service_jobs", "technician_id", "technicians"],
      ["service_job_parts", "service_job_id", "service_jobs"],
      ["service_payments", "service_job_id", "service_jobs"]
    ];
    for (const [collection, field, target] of foreignKeys) {
      const targetIds = new Set(backupData[target].map((record) => record.id));
      if ((backupData[collection] || []).some((record) => !targetIds.has(record[field]))) {
        return { success: false, error: `Backup contains broken references: ${collection}.${field}.` };
      }
    }
    const notificationTypes = ["new_job", "assigned_job", "reassigned_job", "status_change", "payment_received"];
    const statuses = ["received", "diagnosing", "waiting_parts", "repairing", "ready", "completed", "delivered", "cancelled"];
    if ((backupData.notifications || []).some((notification) => !backupData.users.some((user) => user.id === notification.user_id) || !notificationTypes.includes(notification.type) || typeof notification.service_job_id !== "string" || typeof notification.service_number !== "string" || !Number.isFinite(Date.parse(notification.created_at)) || notification.amount !== void 0 && (!Number.isFinite(notification.amount) || notification.amount < 0) || notification.currency_code !== void 0 && typeof notification.currency_code !== "string" || notification.status_id !== void 0 && !statuses.includes(notification.status_id) || notification.previous_status !== void 0 && !statuses.includes(notification.previous_status) || notification.read_at !== void 0 && !Number.isFinite(Date.parse(notification.read_at)) || notification.dismissed_at !== void 0 && !Number.isFinite(Date.parse(notification.dismissed_at)))) {
      return { success: false, error: "Invalid backup notification." };
    }
    if (backupData.id_counters !== void 0 && (!backupData.id_counters || typeof backupData.id_counters !== "object" || Array.isArray(backupData.id_counters) || Object.values(backupData.id_counters).some((value) => !Number.isSafeInteger(value) || Number(value) < 0))) {
      return { success: false, error: "Invalid backup ID counters." };
    }
    if (!backupData.settings || typeof backupData.settings !== "object" || Array.isArray(backupData.settings)) {
      return { success: false, error: "Invalid backup settings." };
    }
    if (!backupData.users.some((user) => user.role === "admin" && typeof user.username === "string" && user.username)) {
      return { success: false, error: "Backup must contain an administrator account." };
    }
    const safetyBackup = JSON.parse(JSON.stringify(this.data));
    const safetyDir = import_path.default.join(import_path.default.dirname(DB_PATH), "backups");
    if (!import_fs.default.existsSync(safetyDir)) {
      import_fs.default.mkdirSync(safetyDir, { recursive: true });
    }
    const safetyFile = import_path.default.resolve(safetyDir, `safety_before_restore_${Date.now()}_${(0, import_node_crypto3.randomUUID)()}.json`);
    try {
      import_fs.default.writeFileSync(safetyFile, JSON.stringify(safetyBackup, null, 2), "utf-8");
    } catch (e) {
      console.warn("Could not write local safety file", e);
    }
    try {
      this.data = {
        admin_setup_complete: safetyBackup.admin_setup_complete || this.isAdminSetupComplete() || backupData.admin_setup_complete,
        notifications: backupData.notifications || [],
        id_counters: Object.fromEntries(Object.keys({ ...safetyBackup.id_counters, ...backupData.id_counters }).map((key) => [key, Math.max(safetyBackup.id_counters?.[key] || 0, backupData.id_counters?.[key] || 0)])),
        users: backupData.users || [],
        technicians: backupData.technicians || [],
        customers: backupData.customers || [],
        devices: backupData.devices || [],
        service_jobs: backupData.service_jobs || [],
        service_job_parts: backupData.service_job_parts || [],
        service_payments: backupData.service_payments || [],
        income_records: backupData.income_records || [],
        expense_records: backupData.expense_records || [],
        settlements: backupData.settlements || [],
        security_audit: backupData.security_audit || [],
        login_attempts: backupData.login_attempts || [],
        licenses_registry: backupData.licenses_registry || initialSeed.licenses_registry,
        settings: backupData.settings || initialSeed.settings
      };
      if (this.data.admin_setup_complete && !this.data.users.some((user) => user.role === "admin" && Boolean(user.password))) {
        const owners = safetyBackup.users.filter((user) => user.role === "admin" && Boolean(user.password));
        const others = this.data.users.filter((user) => user.role !== "admin");
        if (owners.some((owner) => others.some((user) => user.id === owner.id || user.username.toLowerCase() === owner.username.toLowerCase()))) throw new Error("Backup account conflicts with the configured administrator.");
        this.data.users = [...others, ...owners];
      }
      this.ensureCashierCodes();
      this.saveDatabase();
      return { success: true };
    } catch (err) {
      this.data = safetyBackup;
      this.saveDatabase();
      return { success: false, error: err?.message || "Failed restoring database state." };
    }
  }
  // --- Customers & Devices ---
  getCustomers() {
    return this.data.customers;
  }
  getCustomerById(id) {
    return this.data.customers.find((c) => c.id === id);
  }
  createCustomer(cust) {
    const id = `CUST-${String(this.nextNumber("customers")).padStart(3, "0")}`;
    const newCust = {
      ...cust,
      id,
      created_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    this.data.customers.push(newCust);
    this.saveDatabase();
    return newCust;
  }
  updateCustomer(id, updates) {
    const index = this.data.customers.findIndex((c) => c.id === id);
    if (index === -1) return null;
    this.data.customers[index] = { ...this.data.customers[index], ...updates, id, created_at: this.data.customers[index].created_at };
    this.saveDatabase();
    return this.data.customers[index];
  }
  customerDeletionRecords(ids) {
    const selected = new Set(ids);
    const customers = this.data.customers.filter((c) => selected.has(c.id));
    const devices = this.data.devices.filter((d) => selected.has(d.customer_id));
    const deviceIds = new Set(devices.map((d) => d.id));
    if (this.data.service_jobs.some((j) => deviceIds.has(j.device_id) && !selected.has(j.customer_id))) {
      throw new Error("A selected device belongs to another customer\u2019s repair job. Correct that relationship before deleting.");
    }
    const jobs = this.data.service_jobs.filter((j) => selected.has(j.customer_id));
    const jobIds = new Set(jobs.map((j) => j.id));
    const jobNumbers = new Set(jobs.map((j) => j.service_number));
    const payments = this.data.service_payments.filter((p) => jobIds.has(p.service_job_id));
    const paymentIds = new Set(payments.map((p) => p.id));
    return {
      customers,
      devices,
      jobs,
      parts: this.data.service_job_parts.filter((p) => jobIds.has(p.service_job_id)),
      payments,
      income: (this.data.income_records || []).filter((i) => i.service_job_id && jobIds.has(i.service_job_id) || i.service_number && jobNumbers.has(i.service_number) || paymentIds.has(i.reference)),
      notifications: (this.data.notifications || []).filter((n) => jobIds.has(n.service_job_id))
    };
  }
  previewCustomerDeletion(ids) {
    const records = this.customerDeletionRecords(ids);
    return {
      names: records.customers.map((c) => c.name),
      customers: records.customers.length,
      devices: records.devices.length,
      jobs: records.jobs.length,
      parts: records.parts.length,
      payments: records.payments.length,
      income: records.income.length,
      notifications: records.notifications.length,
      revision: (0, import_node_crypto3.createHash)("sha256").update(JSON.stringify(records)).digest("hex")
    };
  }
  deleteCustomersWithRecords(ids, revision, actor, ip) {
    const preview = this.previewCustomerDeletion(ids);
    if (preview.revision !== revision) throw new Error("Records changed. Close this dialog and review the deletion again.");
    const records = this.customerDeletionRecords(ids);
    const backupDirectory = import_path.default.join(import_path.default.dirname(DB_PATH), "backups");
    import_fs.default.mkdirSync(backupDirectory, { recursive: true });
    const backup = `before_customer_delete_${Date.now()}_${(0, import_node_crypto3.randomUUID)()}.json`;
    import_fs.default.writeFileSync(import_path.default.join(backupDirectory, backup), JSON.stringify(this.data, null, 2), { mode: 384 });
    const previous = structuredClone(this.data);
    const retain = (all, removed) => {
      const removedIds = new Set(removed.map((row) => row.id));
      return all.filter((row) => !removedIds.has(row.id));
    };
    try {
      this.data.customers = retain(this.data.customers, records.customers);
      this.data.devices = retain(this.data.devices, records.devices);
      this.data.service_jobs = retain(this.data.service_jobs, records.jobs);
      this.data.service_job_parts = retain(this.data.service_job_parts, records.parts);
      this.data.service_payments = retain(this.data.service_payments, records.payments);
      this.data.income_records = retain(this.data.income_records || [], records.income);
      this.data.notifications = retain(this.data.notifications || [], records.notifications);
      this.data.security_audit.unshift({ id: `AUD-${String(this.nextNumber("security_audit")).padStart(4, "0")}`, user_id: actor.id, username: actor.username, action: "CUSTOMERS_AND_LINKED_RECORDS_DELETED", target_type: "system", target_id: ids.join(","), details: `Deleted ${preview.customers} customers, ${preview.devices} devices, ${preview.jobs} jobs, ${preview.payments} payments and ${preview.income} income records. Safety backup: ${backup}`, ip_address: ip, created_at: (/* @__PURE__ */ new Date()).toISOString() });
      this.saveDatabase();
      return { backup, deleted: preview };
    } catch (error) {
      this.data = previous;
      throw error;
    }
  }
  deleteCustomer(id) {
    const initialLength = this.data.customers.length;
    this.data.customers = this.data.customers.filter((c) => c.id !== id);
    if (this.data.customers.length !== initialLength) {
      this.saveDatabase();
      return true;
    }
    return false;
  }
  getDevices() {
    return this.data.devices;
  }
  getDeviceById(id) {
    return this.data.devices.find((d) => d.id === id);
  }
  createDevice(dev) {
    const id = `DEV-${String(this.nextNumber("devices")).padStart(3, "0")}`;
    const newDev = {
      ...dev,
      id,
      created_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    this.data.devices.push(newDev);
    this.saveDatabase();
    return newDev;
  }
  updateDevice(id, updates) {
    const index = this.data.devices.findIndex((d) => d.id === id);
    if (index === -1) return null;
    this.data.devices[index] = { ...this.data.devices[index], ...updates, id, created_at: this.data.devices[index].created_at };
    this.saveDatabase();
    return this.data.devices[index];
  }
  deleteDevice(id) {
    const index = this.data.devices.findIndex((d) => d.id === id);
    if (index !== -1) {
      this.data.devices.splice(index, 1);
      this.saveDatabase();
      return true;
    }
    return false;
  }
  // --- Settings ---
  getSettings() {
    if (!this.data.settings.paymentSettings?.china) this.data.settings.paymentSettings = { ...defaultPaymentSettings, ...this.data.settings.paymentSettings, china: structuredClone(defaultPaymentSettings.china) };
    this.data.settings.currency_mode = "manual";
    if (!["my", "en", "th", "zh"].includes(this.data.settings.language)) this.data.settings.language = "en";
    return this.data.settings;
  }
  updateSettings(newSettings) {
    if (newSettings.paymentSettings) {
      const previous = this.getSettings().paymentSettings || defaultPaymentSettings;
      const supplied = newSettings.paymentSettings;
      const merged = { ...previous, ...supplied };
      for (const profile of ["thailand", "myanmar", "china", "global"]) {
        const methods = new Map((previous[profile]?.methods || defaultPaymentSettings[profile].methods).map((method) => [method.id, method]));
        for (const method of supplied[profile]?.methods || []) methods.set(method.id, { ...methods.get(method.id), ...method });
        merged[profile] = { methods: [...methods.values()] };
      }
      newSettings = { ...newSettings, paymentSettings: merged };
    }
    this.data.settings = { ...this.data.settings, ...newSettings, currency_mode: "manual" };
    this.saveDatabase();
    return this.data.settings;
  }
  // --- License Management (Client State) ---
  getLicense() {
    if (!this.data.settings.license) {
      this.data.settings.license = {
        license_name: "Free Phone Service Management System",
        plan: "FREE",
        status: "ACTIVE",
        license_key: "FREE-COMMUNITY-EDITION",
        installation_id: "FIXFLOW-INST-882194",
        license_days: 30,
        expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1e3).toISOString(),
        last_verified_at: (/* @__PURE__ */ new Date()).toISOString(),
        server_url: "https://posowner.myominaung.xyz",
        owner_verified: true
      };
      this.saveDatabase();
    }
    const lic = this.data.settings.license;
    if (lic.expires_at) {
      const now = Date.now();
      const expTime = new Date(lic.expires_at).getTime();
      const diffDays = Math.ceil((expTime - now) / (1e3 * 60 * 60 * 24));
      lic.license_days = Math.max(0, diffDays);
      if (lic.license_days <= 0 && lic.status === "ACTIVE") {
        lic.status = "EXPIRED";
      }
    } else if (lic.status === "NOT_ACTIVATED") {
      lic.license_days = 0;
    }
    return lic;
  }
  updateLicense(updates) {
    const current = this.getLicense();
    this.data.settings.license = {
      ...current,
      ...updates
    };
    this.saveDatabase();
    return this.getLicense();
  }
  // --- Telegram Bot Service ---
  getTelegramBot() {
    if (!this.data.settings.telegramBot) {
      this.data.settings.telegramBot = {
        enabled: false,
        bot_token: "",
        chat_id: "",
        channel_username: "",
        notify_on_new_job: true,
        notify_on_status_change: true,
        notify_on_payment: false,
        notify_on_daily_summary: false,
        is_connected: false
      };
      this.saveDatabase();
    }
    return this.data.settings.telegramBot;
  }
  updateTelegramBot(updates) {
    const current = this.getTelegramBot();
    this.data.settings.telegramBot = {
      ...current,
      ...updates
    };
    this.saveDatabase();
    return this.getTelegramBot();
  }
  getLicensesRegistry() {
    if (!this.data.licenses_registry) {
      this.data.licenses_registry = initialSeed.licenses_registry;
      this.saveDatabase();
    }
    return this.data.licenses_registry;
  }
  generateLicenseKey(plan, days, licenseName, createdBy) {
    const registry = this.getLicensesRegistry();
    const randomSuffix = Math.random().toString(36).substring(2, 8).toUpperCase();
    const prefix = plan === "PAID" ? "PAID-PRO" : "FREE-COMM";
    const key = `${prefix}-${(/* @__PURE__ */ new Date()).getFullYear()}-${days}D-${randomSuffix}`;
    const newItem = {
      id: `LIC-${Date.now()}`,
      license_key: key,
      plan,
      license_name: licenseName || (plan === "PAID" ? "FixFlow Professional Phone Service System" : "Free Phone Service Management System"),
      days,
      status: "ACTIVE",
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      created_by: createdBy || "admin"
    };
    registry.unshift(newItem);
    this.saveDatabase();
    return newItem;
  }
  revokeLicenseKey(keyId) {
    const registry = this.getLicensesRegistry();
    const idx = registry.findIndex((l) => l.id === keyId || l.license_key === keyId);
    if (idx !== -1) {
      registry[idx].status = "REVOKED";
      if (this.data.settings.license?.license_key === registry[idx].license_key) {
        this.data.settings.license.status = "REVOKED";
        this.data.settings.license.owner_verified = false;
      }
      this.saveDatabase();
    }
  }
};
var db = new Database();

// server.ts
var recoveryKeys = new RecoveryKeyStore(import_path2.default.resolve(process.env.FIXFLOW_DATA_DIR || "data", ".security"));
var app = (0, import_express.default)();
var port = Number(process.env.PORT || 3e3);
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");
app.use(import_express.default.json({ limit: "50mb" }));
app.use(import_express.default.urlencoded({ extended: true, limit: "50mb" }));
app.get("/api/health", (_req, res) => {
  return res.json({
    ok: true,
    status: "online",
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    server: "FixFlow-Node"
  });
});
var sessions = /* @__PURE__ */ new Map();
var credentialFor = (user) => {
  const tech = user.technician_id ? db.getTechnicianById(user.technician_id) : void 0;
  return (0, import_node_crypto4.createHash)("sha256").update(String(user.password || tech?.password || "")).digest("hex");
};
var authenticate = (req, _res, next) => {
  const token = req.headers.authorization?.startsWith("Bearer ") ? req.headers.authorization.slice(7) : "";
  const session = sessions.get(token);
  if (session) {
    const user = db.getUsers().find((u) => u.id === session.userId);
    const tech = user?.technician_id ? db.getTechnicianById(user.technician_id) : void 0;
    if (user && user.active !== false && session.expiresAt > Date.now() && session.credential === credentialFor(user) && (user.role !== "technician" || tech?.status === "active")) {
      req.user = user;
    } else {
      sessions.delete(token);
    }
  }
  next();
};
function withoutCredentials(value) {
  if (Array.isArray(value)) return value.map(withoutCredentials);
  if (value && typeof value === "object") return Object.fromEntries(
    Object.entries(value).filter(([key]) => key !== "password" && key !== "password_hash").map(([key, item]) => [key, withoutCredentials(item)])
  );
  return value;
}
app.use((req, res, next) => {
  const originalJson = res.json.bind(res);
  res.json = (body) => originalJson(req.path === "/api/backup" ? body : withoutCredentials(body));
  next();
});
app.use((req, res, next) => {
  for (const field of ["currency", "currency_code"]) {
    if (req.body?.[field] !== void 0 && !["MMK", "USD", "THB", "CNY"].includes(req.body[field])) return res.status(400).json({ error: "Choose MMK, USD, THB or CNY." });
  }
  if (req.path === "/api/settings" && req.method === "PUT") {
    if (req.body.language !== void 0 && !["my", "en", "th", "zh"].includes(req.body.language)) return res.status(400).json({ error: "Choose Myanmar, English, Thai or Chinese." });
    req.body.currency_mode = "manual";
  }
  next();
});
app.use((req, res, next) => {
  authenticate(req, res, () => {
    const publicPaths = ["/api/auth/setup-status", "/api/auth/setup-admin", "/api/health", "/api/auth/login", "/api/auth/recover-password", "/api/auth/default-credentials", "/api/system/network-info"];
    if (publicPaths.includes(req.path) || req.method === "GET" && req.path === "/api/license") {
      return next();
    }
    if (!req.user && req.path.startsWith("/api/")) {
      return res.status(401).json({ error: "Unauthorized: Authentication required." });
    }
    if (req.user?.role === "cashier" && req.path.startsWith("/api/")) {
      const readPaths = ["/api/auth/me", "/api/jobs", "/api/technicians", "/api/customers", "/api/devices", "/api/payments", "/api/settings", "/api/notifications"];
      const readAllowed = req.method === "GET" && (readPaths.includes(req.path) || /^\/api\/jobs\/[^/]+$/.test(req.path));
      const writeAllowed = req.method === "POST" && ["/api/jobs", "/api/payments", "/api/customers", "/api/devices", "/api/auth/logout", "/api/auth/change-password"].includes(req.path) || req.method === "PUT" && req.path === "/api/auth/profile" || ["PUT", "DELETE"].includes(req.method) && /^\/api\/notifications(?:\/.*)?$/.test(req.path) || req.method === "POST" && /^\/api\/payments\/[^/]+\/receipt-printed$/.test(req.path);
      if (!readAllowed && !writeAllowed) return res.status(403).json({ error: "Cashier access is limited to intake, payment collection and receipts." });
    }
    next();
  });
});
var isPaidPlanActive = () => {
  const license = db.getLicense();
  return Boolean(license && license.plan === "PAID" && license.status === "ACTIVE");
};
async function dispatchTelegramAlert(eventType, htmlContent) {
  try {
    const config = db.getTelegramBot();
    if (!config || !config.enabled || !config.bot_token || !config.chat_id) return;
    if (eventType === "new_job" && !config.notify_on_new_job) return;
    if (eventType === "status_change" && !config.notify_on_status_change) return;
    if (eventType === "payment" && !config.notify_on_payment) return;
    if (eventType === "daily_summary" && !config.notify_on_daily_summary) return;
    const results = [await sendRawTelegramMessage(config.bot_token, config.chat_id, htmlContent)];
    if (config.channel_username && config.channel_username.trim() && config.channel_username.trim() !== config.chat_id.trim()) {
      results.push(await sendRawTelegramMessage(config.bot_token, config.channel_username.trim(), htmlContent));
    }
    if (results.some((r) => !r.ok)) {
      db.updateTelegramBot({ is_connected: false });
      console.warn("[Telegram Dispatch Warning]", results.filter((r) => !r.ok).map((r) => r.description).join("; "));
    }
  } catch {
    console.warn("[Telegram Dispatch Warning] Dispatch failed.");
  }
}
var recoveryAttempts = /* @__PURE__ */ new Map();
app.post("/api/auth/recover-password", (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  const ip = req.ip || "unknown";
  let attempts = recoveryAttempts.get(ip);
  if (!attempts || attempts.until < Date.now()) {
    attempts = { count: 0, until: Date.now() + 15 * 60 * 1e3 };
    recoveryAttempts.set(ip, attempts);
  }
  if (attempts.count >= 5) return res.status(429).json({ error: "Too many recovery attempts. Try again in 15 minutes." });
  const { username, recovery_key, new_password } = req.body;
  const requested = typeof username === "string" && username.trim().length <= 32 ? username.trim() : "";
  const user = requested ? db.getUserByUsername(requested === "tech1" ? "kyawzin" : requested) : void 0;
  const technician = user?.technician_id ? db.getTechnicianById(user.technician_id) : void 0;
  if (!user || user.active === false || user.role === "technician" && technician?.status !== "active" || !recoveryKeys.verify(recovery_key)) {
    attempts.count++;
    return res.status(400).json({ error: "Account or recovery key is invalid for this PC." });
  }
  if (typeof new_password !== "string" || new_password.length < 8 || new_password.length > 128) return res.status(400).json({ error: "New password must contain 8\u2013128 characters." });
  try {
    const recovery = recoveryKeys.rotate(() => db.resetPasswordTransaction(user.id, hashPassword(new_password), ip));
    for (const [token, session] of sessions) if (session.userId === user.id) sessions.delete(token);
    recoveryAttempts.delete(ip);
    return res.json({ success: true, recovery });
  } catch {
    return res.status(500).json({ error: "Recovery could not be saved. Check database and local recovery-key storage access." });
  }
});
var checkRecoveryAdmin = (req, res, next) => {
  res.setHeader("Cache-Control", "no-store");
  if (req.user?.role !== "admin") return res.status(403).json({ error: "Administrator access required." });
  const stored = req.user.password;
  const valid = stored ? verifyPassword(req.body.current_password, stored) : req.body.current_password === "admin123";
  if (!valid) return res.status(403).json({ error: "Enter the current administrator password." });
  next();
};
app.get("/api/auth/recovery/status", (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  if (req.user?.role !== "admin") return res.status(403).json({ error: "Administrator access required." });
  return res.json(recoveryKeys.status());
});
app.post("/api/auth/recovery/backup", checkRecoveryAdmin, (_req, res) => res.json(recoveryKeys.backup()));
app.post("/api/auth/recovery/rotate", checkRecoveryAdmin, (req, res) => {
  try {
    const backup = recoveryKeys.rotate(() => db.auditTransaction({ user_id: req.user.id, username: req.user.username, action: "RECOVERY_KEY_ROTATED", target_type: "auth", target_id: req.user.id, details: "Administrator generated a replacement recovery backup key.", ip_address: req.ip || "127.0.0.1" }));
    return res.json(backup);
  } catch {
    return res.status(500).json({ error: "Recovery key could not be saved." });
  }
});
app.get("/api/auth/default-credentials", (_req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.json({ credentials: [] });
});
app.get("/api/auth/setup-status", (_req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.json({ registration_open: !db.isAdminSetupComplete() });
});
app.post("/api/auth/setup-admin", (req, res) => {
  if (db.isAdminSetupComplete()) return res.status(409).json({ error: "Admin registration is already completed." });
  const { full_name, username, password } = req.body;
  if (typeof full_name !== "string" || !full_name.trim() || full_name.length > 100 || typeof username !== "string" || !/^[A-Za-z0-9_.-]{3,32}$/.test(username) || username.toLowerCase() === "tech1" || typeof password !== "string" || password.length < 8 || password.length > 128) return res.status(400).json({ error: "Enter a name, unique username and a password of at least 8 characters." });
  if (db.getUsers().some((user) => user.username.toLowerCase() === username.toLowerCase() && !(user.role === "admin" && user.username === "admin" && !user.password))) return res.status(409).json({ error: "Username is already in use." });
  try {
    const user = db.setupFirstAdmin({ full_name: full_name.trim(), username, password: hashPassword(password) });
    return res.status(201).json({ user });
  } catch {
    return res.status(500).json({ error: "Administrator account could not be saved. Try again." });
  }
});
app.post("/api/auth/login", (req, res) => {
  if (!db.isAdminSetupComplete()) return res.status(409).json({ error: "Create your administrator account first." });
  const { username, password } = req.body;
  const ip = req.ip || "127.0.0.1";
  if (typeof username !== "string" || !username.trim() || typeof password !== "string" || !password) {
    return res.status(400).json({ error: "Username and password are required" });
  }
  let resolvedUsername = username;
  if (username === "tech1") resolvedUsername = "kyawzin";
  const user = db.getUserByUsername(resolvedUsername);
  if (!user) {
    db.recordLoginAttempt(username, false, ip);
    return res.status(401).json({ error: "Invalid username or credentials" });
  }
  if (user.role === "admin" && !user.password) return res.status(401).json({ error: "Administrator password is not configured. Use password recovery." });
  if (user.active === false) return res.status(403).json({ error: "Account is inactive." });
  if (user.role === "technician" && db.getTechnicianById(user.technician_id || "")?.status !== "active") {
    return res.status(403).json({ error: "Technician account is inactive." });
  }
  if (password !== void 0) {
    let validPassword = false;
    const tech = user.technician_id ? db.getTechnicians().find((t) => t.id === user.technician_id) : null;
    const storedPass = user.password || tech?.password;
    if (storedPass) {
      validPassword = verifyPassword(password, storedPass);
    } else {
      const defaultPass = user.role === "admin" ? "admin123" : "tech123";
      validPassword = password === defaultPass;
    }
    if (!validPassword) {
      db.recordLoginAttempt(username, false, ip);
      return res.status(401).json({ error: "Invalid password credentials" });
    }
  }
  db.recordLoginAttempt(username, true, ip);
  db.recordAudit({
    user_id: user.id,
    username: user.username,
    technician_id: user.technician_id,
    action: "USER_LOGIN",
    target_type: "auth",
    target_id: user.id,
    details: `User ${user.username} (${user.role}) logged in successfully.`,
    ip_address: ip
  });
  for (const [token2, session] of sessions) {
    if (session.expiresAt <= Date.now()) sessions.delete(token2);
  }
  const token = (0, import_node_crypto4.randomBytes)(32).toString("hex");
  sessions.set(token, { userId: user.id, expiresAt: Date.now() + 12 * 60 * 60 * 1e3, credential: credentialFor(user) });
  return res.json({ token, user });
});
app.get("/api/auth/me", (req, res) => {
  if (!req.user) {
    return res.status(401).json({ error: "Not authenticated" });
  }
  return res.json({ user: req.user });
});
app.post("/api/auth/logout", (req, res) => {
  sessions.delete(req.headers.authorization?.slice(7) || "");
  if (req.user) {
    db.recordAudit({
      user_id: req.user.id,
      username: req.user.username,
      technician_id: req.user.technician_id,
      action: "USER_LOGOUT",
      target_type: "auth",
      target_id: req.user.id,
      details: `User ${req.user.username} logged out.`,
      ip_address: req.ip || "127.0.0.1"
    });
  }
  return res.json({ success: true, message: "Logged out successfully." });
});
app.post("/api/auth/change-password", (req, res) => {
  if (!req.user) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  const { current_password, new_password } = req.body;
  if (!current_password || !new_password) {
    return res.status(400).json({ error: "Current password and new password are required." });
  }
  const tech = req.user.technician_id ? db.getTechnicians().find((t) => t.id === req.user?.technician_id) : null;
  const storedPass = req.user.password || tech?.password;
  let validCurrent = false;
  if (storedPass) {
    validCurrent = verifyPassword(current_password, storedPass);
  } else {
    const defaultPass = req.user.role === "admin" ? "admin123" : "tech123";
    validCurrent = current_password === defaultPass;
  }
  if (!validCurrent) {
    return res.status(400).json({ error: "Incorrect current password." });
  }
  if (typeof new_password !== "string" || new_password.length < 8) {
    return res.status(400).json({ error: "New password must be at least 8 characters." });
  }
  db.updatePassword(req.user.id, hashPassword(new_password));
  for (const [token, session] of sessions) {
    if (session.userId === req.user.id && token !== req.headers.authorization?.slice(7)) sessions.delete(token);
  }
  const currentSession = sessions.get(req.headers.authorization?.slice(7) || "");
  if (currentSession) currentSession.credential = credentialFor(req.user);
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    technician_id: req.user.technician_id,
    action: "PASSWORD_CHANGED",
    target_type: "auth",
    target_id: req.user.id,
    details: `User ${req.user.username} changed their password successfully.`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.json({ success: true, message: "Password changed successfully." });
});
app.put("/api/auth/profile", (req, res) => {
  if (!req.user) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  const { full_name, username, email, phone, address, profile_photo } = req.body;
  const invalidPhoto = imageValidationError(profile_photo);
  if (invalidPhoto) return res.status(400).json({ error: invalidPhoto });
  if (typeof username !== "string" || !username.trim() || typeof full_name !== "string" || !full_name.trim()) {
    return res.status(400).json({ error: "Full name and username are required." });
  }
  for (const field of ["phone", "email", "address"]) if (req.body[field] !== void 0 && (typeof req.body[field] !== "string" || req.body[field].length > (field === "address" ? 1e3 : 100))) return res.status(400).json({ error: "Enter valid profile contact details." });
  const duplicate = db.getUserByUsername(username.trim());
  if (duplicate && duplicate.id !== req.user.id) return res.status(409).json({ error: "Username is already in use." });
  const updated = db.updateProfile(req.user.id, {
    full_name: full_name.trim(),
    username: username.trim(),
    ...email !== void 0 ? { email } : {},
    ...phone !== void 0 ? { phone } : {},
    ...address !== void 0 ? { address } : {},
    ...profile_photo !== void 0 ? { profile_photo } : {}
  });
  if (!updated) {
    return res.status(404).json({ error: "User not found." });
  }
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    technician_id: req.user.technician_id,
    action: "PROFILE_UPDATED",
    target_type: "auth",
    target_id: req.user.id,
    details: `User ${req.user.username} updated their profile information.`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.json({ success: true, user: updated });
});
app.get("/api/notifications", (req, res) => {
  const notifications = db.getNotifications(req.user.id);
  return res.json({ notifications, unread_count: notifications.filter((notification) => !notification.read_at).length });
});
app.put("/api/notifications/read-all", (req, res) => {
  return res.json({ success: true, updated_count: db.markAllNotificationsRead(req.user.id) });
});
app.put("/api/notifications/:id/read", (req, res) => {
  const notification = db.markNotificationRead(req.params.id, req.user.id);
  if (!notification) return res.status(404).json({ error: "Notification not found." });
  return res.json(notification);
});
app.delete("/api/notifications/read", (req, res) => {
  return res.json({ success: true, dismissed_count: db.clearReadNotifications(req.user.id) });
});
app.delete("/api/notifications/:id", (req, res) => {
  if (!db.dismissNotification(req.params.id, req.user.id)) return res.status(404).json({ error: "Notification not found." });
  return res.json({ success: true });
});
app.post("/api/demo-users", (req, res) => {
  if (req.user?.role !== "admin") return res.status(403).json({ error: "Admin access required." });
  const existing = db.getTechnicians().find((t) => t.is_demo);
  if (existing) return res.json(existing);
  if (db.getUserByUsername("demo_tech")) return res.status(409).json({ error: "demo_tech is already in use by a regular account." });
  const tech = db.createTechnician({ full_name: "Demo Technician", username: "demo_tech", phone: "", email: "", address: "", status: "active", specialization: [], is_demo: true });
  db.recordAudit({ user_id: req.user.id, username: req.user.username, action: "DEMO_USER_ADDED", target_type: "technician", target_id: tech.id, details: "Added demo technician account.", ip_address: req.ip || "127.0.0.1" });
  return res.status(201).json(tech);
});
app.delete("/api/demo-users", (req, res) => {
  if (req.user?.role !== "admin") return res.status(403).json({ error: "Admin access required." });
  const demo = db.getTechnicians().filter((t) => t.is_demo);
  if (demo.some((t) => db.getJobs().some((j) => j.technician_id === t.id))) return res.status(409).json({ error: "Reassign demo users\u2019 repair jobs before deleting them." });
  for (const tech of demo) db.deleteTechnician(tech.id);
  db.recordAudit({ user_id: req.user.id, username: req.user.username, action: "DEMO_USERS_DELETED", target_type: "system", target_id: "demo-users", details: `Deleted ${demo.length} demo accounts.`, ip_address: req.ip || "127.0.0.1" });
  res.json({ success: true, deleted: demo.length });
});
app.get("/api/technicians", (_req, res) => {
  const technicians = db.getTechnicians();
  const jobs = db.getJobs();
  const techsWithWorkload = technicians.map((tech) => {
    const techJobs = jobs.filter((j) => j.technician_id === tech.id);
    const activeJobs = techJobs.filter(
      (j) => !["completed", "delivered", "cancelled"].includes(j.status_id)
    ).length;
    const completedJobs = techJobs.filter(
      (j) => j.status_id === "completed" || j.status_id === "delivered"
    ).length;
    return {
      ...tech,
      activeJobs,
      completedJobs
    };
  });
  return res.json(techsWithWorkload);
});
app.post("/api/users/register", (req, res) => {
  if (req.user?.role !== "admin") return res.status(403).json({ error: "Only administrators can register accounts." });
  const { full_name, username, password, phone = "", email = "", role = "admin" } = req.body;
  if (typeof full_name !== "string" || !full_name.trim() || full_name.length > 100 || typeof username !== "string" || !/^[A-Za-z0-9_.-]{3,32}$/.test(username) || typeof password !== "string" || password.length < 8 || password.length > 128 || typeof phone !== "string" || phone.length > 50 || typeof email !== "string" || email.length > 100 || !["admin", "technician", "cashier"].includes(role)) return res.status(400).json({ error: "Enter valid account details and an Admin, Technician or Cashier role." });
  if (username.toLowerCase() === "tech1" || db.getUsers().some((user2) => user2.username.toLowerCase() === username.toLowerCase())) return res.status(409).json({ error: "Username is already in use." });
  const input = { username, full_name: full_name.trim(), password: hashPassword(password), phone: phone.trim(), email: email.trim() };
  const technician = role === "technician" ? db.createTechnician({ ...input, address: "", status: "active", specialization: [] }) : void 0;
  const user = role === "admin" ? db.createAdmin(input) : role === "cashier" ? db.createCashier(input) : db.getUserByUsername(username);
  db.recordAudit({ user_id: req.user.id, username: req.user.username, action: "USER_REGISTERED", target_type: "auth", target_id: user.id, details: `Administrator registered ${role} account ${username}.`, ip_address: req.ip || "" });
  return res.status(201).json({ user, ...technician ? { technician } : {} });
});
app.post("/api/users/quick-register", (req, res) => {
  if (req.user?.role !== "admin") return res.status(403).json({ error: "Only administrators can register users." });
  const { full_name, username, password, phone = "" } = req.body;
  if (typeof full_name !== "string" || !full_name.trim() || full_name.length > 100 || typeof username !== "string" || !/^[a-zA-Z0-9_.-]{3,32}$/.test(username) || typeof password !== "string" || password.length < 8 || password.length > 128 || typeof phone !== "string" || phone.length > 50) return res.status(400).json({ error: "Enter a name, username (3\u201332 letters/numbers/._-), password (8\u2013128 characters), and optional phone." });
  if (username === "tech1" || db.getUsers().some((u) => u.username.toLowerCase() === username.toLowerCase())) return res.status(409).json({ error: "Username is already in use." });
  const technician = db.createTechnician({ full_name: full_name.trim(), username, password: hashPassword(password), phone: phone.trim(), email: "", address: "", status: "active", specialization: [] });
  db.recordAudit({ user_id: req.user.id, username: req.user.username, action: "USER_REGISTERED", target_type: "technician", target_id: technician.id, details: `Registered technician account ${username}.`, ip_address: req.ip || "" });
  return res.status(201).json({ user: db.getUserByUsername(username), technician });
});
app.post("/api/technicians", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Only administrators can register technicians." });
  }
  let { full_name, username, phone, email, address, specialization, profile_photo, status } = req.body;
  if (!full_name) {
    return res.status(400).json({ error: "Full name is required." });
  }
  if (!username) {
    username = full_name.toLowerCase().replace(/[^a-z0-9]/g, "") || `tech_${Date.now()}`;
  }
  let finalUsername = username;
  let counter = 1;
  while (db.getUserByUsername(finalUsername)) {
    finalUsername = `${username}_${counter++}`;
  }
  const newTech = db.createTechnician({
    full_name,
    username: finalUsername,
    phone: phone || "",
    email: email || "",
    address: address || "",
    profile_photo: profile_photo || "",
    status: status || "active",
    specialization: Array.isArray(specialization) ? specialization : []
  });
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    technician_id: newTech.id,
    action: "TECHNICIAN_REGISTERED",
    target_type: "technician",
    target_id: newTech.id,
    details: `Admin ${req.user.username} registered technician ${newTech.full_name} (${newTech.id}).`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.status(201).json(newTech);
});
app.put("/api/technicians/:id", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Only administrators can edit technicians." });
  }
  const { id } = req.params;
  if (req.body.username !== void 0) {
    if (typeof req.body.username !== "string" || !req.body.username.trim()) return res.status(400).json({ error: "Username is required." });
    const duplicate = db.getUserByUsername(req.body.username.trim());
    if (duplicate && duplicate.technician_id !== id) return res.status(409).json({ error: "Username is already in use." });
  }
  if (req.body.status !== void 0 && !["active", "inactive"].includes(req.body.status)) return res.status(400).json({ error: "Invalid technician status." });
  const allowed = ["full_name", "username", "phone", "email", "address", "specialization", "profile_photo", "status", "level"];
  const payload = Object.fromEntries(Object.entries(req.body).filter(([key]) => allowed.includes(key)));
  const updated = db.updateTechnician(id, payload);
  if (!updated) {
    return res.status(404).json({ error: "Technician not found." });
  }
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    technician_id: id,
    action: "TECHNICIAN_UPDATED",
    target_type: "technician",
    target_id: id,
    details: `Admin ${req.user.username} updated technician ${updated.full_name}.`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.json(updated);
});
app.put("/api/technicians/:id/password", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Only administrators can reset technician passwords." });
  }
  const { id } = req.params;
  const { new_password } = req.body;
  if (!new_password) {
    return res.status(400).json({ error: "New password is required." });
  }
  const tech = db.getTechnicianById(id);
  if (!tech) {
    return res.status(404).json({ error: "Technician not found." });
  }
  if (typeof new_password !== "string" || new_password.length < 8) {
    return res.status(400).json({ error: "New password must be at least 8 characters." });
  }
  const linkedUser = db.getUsers().find((user) => user.technician_id === id);
  if (!linkedUser || !db.updatePassword(linkedUser.id, hashPassword(new_password))) {
    return res.status(500).json({ error: "Could not update the technician password." });
  }
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    technician_id: id,
    action: "PASSWORD_RESET",
    target_type: "technician",
    target_id: id,
    details: `Admin ${req.user.username} reset password for technician ${escapeTelegramHtml(tech.full_name)}.`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.json({ success: true, message: `Password reset successfully for ${escapeTelegramHtml(tech.full_name)}.` });
});
app.delete("/api/technicians/:id", (req, res) => {
  const { id } = req.params;
  const tech = db.getTechnicianById(id);
  if (!tech) {
    return res.status(404).json({ error: "Technician not found." });
  }
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Only administrators can delete technicians." });
  }
  if (db.getJobs().some((j) => j.technician_id === id)) {
    return res.status(409).json({ error: "Reassign this technician's repair jobs before deleting the account." });
  }
  db.deleteTechnician(id);
  db.recordAudit({
    user_id: req.user?.id || "USR-001",
    username: req.user?.username || "admin",
    technician_id: id,
    action: "DELETE_TECHNICIAN",
    target_type: "technician",
    target_id: id,
    details: `Technician ${escapeTelegramHtml(tech.full_name)} (${id}) was deleted.`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.json({ success: true, message: "Technician deleted successfully." });
});
app.get("/api/jobs", (req, res) => {
  const { technician_id, status_id, search, date_from, date_to } = req.query;
  let jobs = db.getJobs();
  if (req.user?.role === "technician") {
    const techId = req.user.technician_id;
    if (!techId) {
      return res.status(403).json({ error: "Forbidden: Technician profile not linked." });
    }
    jobs = jobs.filter((j) => j.technician_id === techId);
  } else if (technician_id && typeof technician_id === "string" && technician_id !== "all") {
    jobs = jobs.filter((j) => j.technician_id === technician_id);
  }
  if (status_id && typeof status_id === "string" && status_id !== "all") {
    jobs = jobs.filter((j) => j.status_id === status_id);
  }
  if (search && typeof search === "string" && search.trim()) {
    const q = search.toLowerCase();
    jobs = jobs.filter((j) => {
      const matchSrv = j.service_number.toLowerCase().includes(q);
      const matchCust = j.customer?.name.toLowerCase().includes(q) || false;
      const matchPhone = j.customer?.phone.toLowerCase().includes(q) || false;
      const matchDev = `${j.device?.brand || ""} ${j.device?.model || ""}`.toLowerCase().includes(q);
      const matchSerial = (j.device?.serial_or_imei || "").toLowerCase().includes(q);
      return matchSrv || matchCust || matchPhone || matchDev || matchSerial;
    });
  }
  if (date_from && typeof date_from === "string") {
    jobs = jobs.filter((j) => new Date(j.created_at) >= new Date(date_from));
  }
  if (date_to && typeof date_to === "string") {
    jobs = jobs.filter((j) => new Date(j.created_at) <= new Date(date_to));
  }
  return res.json(jobs);
});
app.get("/api/jobs/:id", (req, res) => {
  const { id } = req.params;
  const job = db.getJobById(id);
  if (!job) {
    return res.status(404).json({ error: "Service job not found." });
  }
  if (req.user?.role === "technician") {
    if (job.technician_id !== req.user.technician_id) {
      db.recordAudit({
        user_id: req.user.id,
        username: req.user.username,
        technician_id: req.user.technician_id,
        action: "UNAUTHORIZED_ACCESS_ATTEMPT",
        target_type: "job",
        target_id: id,
        details: `Technician ${req.user.username} attempted to access job ${job.service_number} assigned to technician ${job.technician_id}.`,
        ip_address: req.ip || "127.0.0.1"
      });
      return res.status(403).json({
        error: "Forbidden: You do not have permission to view this service job."
      });
    }
  }
  return res.json(job);
});
app.post("/api/jobs", (req, res) => {
  if (!req.user || !["admin", "cashier"].includes(req.user.role)) {
    return res.status(403).json({
      error: "Forbidden: Only administrators can create and assign service jobs."
    });
  }
  const {
    customer_id,
    device_id,
    technician_id,
    problem_description,
    priority,
    service_charge,
    amount_paid,
    payment_method,
    warranty_days,
    passlock_pin
  } = req.body;
  if (!technician_id) {
    return res.status(400).json({
      error: "Technician assignment is mandatory. Please select an assigned technician."
    });
  }
  const tech = db.getTechnicianById(technician_id);
  if (!tech) {
    return res.status(400).json({ error: "Assigned technician does not exist." });
  }
  const customer = db.getCustomerById(customer_id);
  const device = db.getDeviceById(device_id);
  if (!customer || !device || device.customer_id !== customer_id) {
    return res.status(400).json({ error: "Select an existing customer and a device owned by that customer." });
  }
  if ([service_charge ?? 0, amount_paid ?? 0].some((value) => !Number.isFinite(Number(value)) || Number(value) < 0)) {
    return res.status(400).json({ error: "Charges and deposits must be finite non-negative numbers." });
  }
  if (warranty_days !== void 0 && (!Number.isInteger(Number(warranty_days)) || Number(warranty_days) < 0)) return res.status(400).json({ error: "Warranty days must be a non-negative integer." });
  const chargeNum = Number(service_charge) || 0;
  const paidNum = Number(amount_paid) || 0;
  const payment_status = paidNum >= chargeNum && chargeNum > 0 ? "paid" : paidNum > 0 ? "partial" : "unpaid";
  const newJob = db.createJob({
    intake_received_by: req.user.full_name || req.user.username,
    intake_username: req.user.username,
    ...req.user.role === "cashier" ? { intake_cashier_id: req.user.id } : {},
    customer_id,
    device_id,
    technician_id,
    // Linked using foreign key
    status_id: "received",
    priority: priority || "normal",
    problem_description: problem_description || "Intake service request",
    service_charge: chargeNum,
    parts_cost: 0,
    total_cost: chargeNum,
    amount_paid: paidNum,
    currency_code: req.body.currency_code || db.getSettings().currency || "MMK",
    payment_status,
    payment_method: payment_method || "cash",
    warranty_days: warranty_days === void 0 ? 30 : Number(warranty_days),
    passlock_pin: passlock_pin || "",
    received_at: (/* @__PURE__ */ new Date()).toISOString()
  });
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    technician_id,
    action: "JOB_CREATED_AND_ASSIGNED",
    target_type: "job",
    target_id: newJob.id,
    details: `Admin ${req.user.username} created job ${newJob.service_number} and assigned to technician ${escapeTelegramHtml(tech.full_name)} (${tech.id}).`,
    ip_address: req.ip || "127.0.0.1"
  });
  const cust = db.getCustomerById(newJob.customer_id);
  const dev = db.getDeviceById(newJob.device_id);
  const cur = newJob.currency_code || "MMK";
  dispatchTelegramAlert(
    "new_job",
    `\u{1F514} <b>New Service Job Received</b>
<b>Ticket:</b> <code>${newJob.service_number}</code>
<b>Customer:</b> ${escapeTelegramHtml(cust?.name || "Walk-in")} (${escapeTelegramHtml(cust?.phone || "N/A")})
<b>Device:</b> ${escapeTelegramHtml(dev ? `${dev.brand} ${dev.model}` : "Device")}
<b>Problem:</b> ${escapeTelegramHtml(newJob.problem_description)}
<b>Labor Charge:</b> ${escapeTelegramHtml(cur)} ${(newJob.service_charge || 0).toLocaleString()}
<b>Technician:</b> ${escapeTelegramHtml(tech.full_name)}
<b>Priority:</b> ${(newJob.priority || "normal").toUpperCase()}`
  );
  return res.status(201).json(newJob);
});
var validStatuses = /* @__PURE__ */ new Set(["received", "diagnosing", "waiting_parts", "repairing", "ready", "completed", "delivered", "cancelled"]);
var jobEditFields = /* @__PURE__ */ new Set([
  "status_id",
  "priority",
  "diagnosis",
  "repair_notes",
  "completion_notes",
  "warranty_days",
  "parts_used",
  "service_charge",
  "parts_cost",
  "total_cost",
  "amount_paid",
  "technician_id",
  "problem_description",
  "passlock_pin",
  "category_id",
  "payment_method"
]);
app.use("/api/jobs", (req, res, next) => {
  if (req.method === "PUT") {
    if (req.body.status_id !== void 0 && !validStatuses.has(req.body.status_id)) {
      return res.status(400).json({ error: "Invalid repair status." });
    }
    if (Object.keys(req.body).some((key) => !jobEditFields.has(key))) {
      return res.status(400).json({ error: "Unsupported or immutable job field." });
    }
    if (req.body.technician_id !== void 0 && !db.getTechnicianById(req.body.technician_id)) {
      return res.status(400).json({ error: "Assigned technician does not exist." });
    }
  }
  if (req.body.warranty_days !== void 0 && (!Number.isInteger(Number(req.body.warranty_days)) || Number(req.body.warranty_days) < 0)) {
    return res.status(400).json({ error: "Warranty days must be a non-negative integer." });
  }
  if (req.body.service_charge !== void 0 && (!Number.isFinite(Number(req.body.service_charge)) || Number(req.body.service_charge) < 0)) {
    return res.status(400).json({ error: "Service charge must be a finite non-negative number." });
  }
  if (req.body.parts_used !== void 0) {
    if (!Array.isArray(req.body.parts_used) || req.body.parts_used.some((p) => !p || !p.part_name || !Number.isInteger(Number(p.quantity)) || Number(p.quantity) <= 0 || !Number.isFinite(Number(p.unit_cost)) || Number(p.unit_cost) < 0)) {
      return res.status(400).json({ error: "Parts require a name, positive integer quantity and finite non-negative unit cost." });
    }
    req.body.parts_used = req.body.parts_used.map((p) => ({ ...p, quantity: Number(p.quantity), unit_cost: Number(p.unit_cost), total_cost: Number(p.quantity) * Number(p.unit_cost) }));
  }
  next();
});
app.put("/api/jobs/:id", (req, res) => {
  const { id } = req.params;
  const existingJob = db.getJobById(id);
  if (!existingJob) {
    return res.status(404).json({ error: "Service job not found." });
  }
  if (req.user?.role === "technician") {
    if (existingJob.technician_id !== req.user.technician_id) {
      db.recordAudit({
        user_id: req.user.id,
        username: req.user.username,
        technician_id: req.user.technician_id,
        action: "UNAUTHORIZED_EDIT_ATTEMPT",
        target_type: "job",
        target_id: id,
        details: `Technician ${req.user.username} attempted to edit job ${existingJob.service_number} assigned to technician ${existingJob.technician_id}.`,
        ip_address: req.ip || "127.0.0.1"
      });
      return res.status(403).json({
        error: "Forbidden: You can only edit jobs assigned to you."
      });
    }
    if (req.body.technician_id && req.body.technician_id !== existingJob.technician_id) {
      return res.status(403).json({
        error: "Forbidden: Technicians are not allowed to reassign service jobs to other technicians."
      });
    }
    if (req.body.service_charge !== void 0 && Number(req.body.service_charge) !== existingJob.service_charge) {
      db.recordAudit({
        user_id: req.user.id,
        username: req.user.username,
        technician_id: req.user.technician_id,
        action: "UNAUTHORIZED_FINANCIAL_ATTEMPT",
        target_type: "job",
        target_id: id,
        details: `Technician @${req.user.username} attempted to alter service charge for job ${existingJob.service_number} from ${existingJob.service_charge} to ${req.body.service_charge}. Action blocked.`,
        ip_address: req.ip || "127.0.0.1"
      });
      return res.status(403).json({
        error: "Forbidden: Technicians are not allowed to alter service charges. Financial alterations are restricted to Administrators."
      });
    }
    if (req.body.amount_paid !== void 0 && Number(req.body.amount_paid) !== existingJob.amount_paid) {
      db.recordAudit({
        user_id: req.user.id,
        username: req.user.username,
        technician_id: req.user.technician_id,
        action: "UNAUTHORIZED_FINANCIAL_ATTEMPT",
        target_type: "job",
        target_id: id,
        details: `Technician @${req.user.username} attempted to alter payment amount for job ${existingJob.service_number}. Action blocked.`,
        ip_address: req.ip || "127.0.0.1"
      });
      return res.status(403).json({
        error: "Forbidden: Technicians are not allowed to record or modify payments. Financial management is restricted to Administrators."
      });
    }
  }
  const parts_used = req.body.parts_used || existingJob.parts_used || [];
  const parts_cost = parts_used.reduce((sum, p) => sum + (Number(p.total_cost) || 0), 0);
  const service_charge = req.body.service_charge !== void 0 ? Number(req.body.service_charge) : existingJob.service_charge;
  const total_cost = service_charge + parts_cost;
  const amount_paid = existingJob.amount_paid;
  const payment_status = amount_paid >= total_cost && total_cost > 0 ? "paid" : amount_paid > 0 ? "partial" : "unpaid";
  let completed_at = existingJob.completed_at;
  let delivered_at = existingJob.delivered_at;
  if (req.body.status_id === "completed" && !completed_at) {
    completed_at = (/* @__PURE__ */ new Date()).toISOString();
  }
  if (req.body.status_id === "delivered" && !delivered_at) {
    delivered_at = (/* @__PURE__ */ new Date()).toISOString();
  }
  const updates = {
    ...req.body,
    parts_cost,
    service_charge,
    total_cost,
    amount_paid,
    payment_status,
    completed_at,
    delivered_at
  };
  if (req.user?.role === "technician") {
    updates.technician_id = existingJob.technician_id;
  }
  const updatedJob = db.updateJob(id, updates);
  db.recordAudit({
    user_id: req.user ? req.user.id : "USR-001",
    username: req.user ? req.user.username : "admin",
    technician_id: updatedJob?.technician_id,
    action: req.body.status_id && req.body.status_id !== existingJob.status_id ? "STATUS_UPDATE" : "JOB_UPDATE",
    target_type: "job",
    target_id: id,
    details: `${req.user?.role === "admin" ? "Admin" : "Technician"} ${req.user?.username} updated job ${existingJob.service_number} (Status: ${updatedJob?.status_id}).`,
    ip_address: req.ip || "127.0.0.1"
  });
  if (req.body.status_id && req.body.status_id !== existingJob.status_id && updatedJob) {
    const cust = db.getCustomerById(updatedJob.customer_id);
    const dev = db.getDeviceById(updatedJob.device_id);
    const tech = db.getTechnicianById(updatedJob.technician_id);
    const statusEmoji = {
      received: "\u{1F4E5}",
      diagnosing: "\u{1F50D}",
      waiting_parts: "\u23F3",
      repairing: "\u{1F6E0}\uFE0F",
      ready: "\u2705",
      completed: "\u{1F389}",
      delivered: "\u{1F4E6}",
      cancelled: "\u274C"
    };
    const emoji = statusEmoji[updatedJob.status_id] || "\u{1F504}";
    dispatchTelegramAlert(
      "status_change",
      `${emoji} <b>Repair Status Updated</b>
<b>Ticket:</b> <code>${updatedJob.service_number}</code>
<b>New Status:</b> <b>${updatedJob.status_id.toUpperCase().replace("_", " ")}</b> (was: ${existingJob.status_id})
<b>Customer:</b> ${escapeTelegramHtml(cust?.name || "Customer")}
<b>Device:</b> ${escapeTelegramHtml(dev ? `${dev.brand} ${dev.model}` : "Device")}
<b>Technician:</b> ${escapeTelegramHtml(tech?.full_name || "N/A")}
` + (updatedJob.diagnosis ? `<b>Diagnosis:</b> ${escapeTelegramHtml(updatedJob.diagnosis)}
` : "") + (updatedJob.repair_notes ? `<b>Repair Notes:</b> ${escapeTelegramHtml(updatedJob.repair_notes)}
` : "")
    );
  }
  return res.json(updatedJob);
});
app.post("/api/jobs/:id/parts", (req, res) => {
  const { id } = req.params;
  const existingJob = db.getJobById(id);
  if (!existingJob) {
    return res.status(404).json({ error: "Service job not found." });
  }
  if (req.user?.role === "technician" && existingJob.technician_id !== req.user.technician_id) {
    return res.status(403).json({ error: "Forbidden: You can only add parts to your assigned jobs." });
  }
  const { part_name, part_number, quantity, unit_cost, warranty } = req.body;
  if (!part_name) {
    return res.status(400).json({ error: "Part name is required." });
  }
  const qty = Number(quantity ?? 1);
  const cost = Number(unit_cost ?? 0);
  if (!Number.isInteger(qty) || qty <= 0 || !Number.isFinite(cost) || cost < 0) {
    return res.status(400).json({ error: "Quantity must be a positive integer and cost must be finite and non-negative." });
  }
  const newPart = {
    id: `PART-${Date.now()}-${Math.floor(Math.random() * 1e3)}`,
    service_job_id: id,
    part_name,
    part_number: part_number || "",
    quantity: qty,
    unit_cost: cost,
    total_cost: qty * cost,
    warranty: warranty || "30 Days",
    created_at: (/* @__PURE__ */ new Date()).toISOString()
  };
  const updatedParts = [...existingJob.parts_used || [], newPart];
  const parts_cost = updatedParts.reduce((sum, p) => sum + (p.total_cost || 0), 0);
  const total_cost = (existingJob.service_charge || 0) + parts_cost;
  const updatedJob = db.updateJob(id, {
    parts_used: updatedParts,
    parts_cost,
    total_cost
  });
  db.recordAudit({
    user_id: req.user ? req.user.id : "USR-001",
    username: req.user ? req.user.username : "admin",
    technician_id: updatedJob?.technician_id,
    action: "JOB_PART_ADDED",
    target_type: "job",
    target_id: id,
    details: `${req.user?.username} added part "${part_name}" (Qty: ${qty}) to job ${existingJob.service_number}.`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.status(201).json(updatedJob);
});
app.put("/api/jobs/:id/status", (req, res) => {
  const { id } = req.params;
  const existingJob = db.getJobById(id);
  if (!existingJob) {
    return res.status(404).json({ error: "Service job not found." });
  }
  if (req.user?.role === "technician" && existingJob.technician_id !== req.user.technician_id) {
    return res.status(403).json({ error: "Forbidden: You can only update your assigned jobs." });
  }
  const { status_id } = req.body;
  if (!status_id) {
    return res.status(400).json({ error: "status_id is required." });
  }
  let completed_at = existingJob.completed_at;
  let delivered_at = existingJob.delivered_at;
  if (status_id === "completed" && !completed_at) {
    completed_at = (/* @__PURE__ */ new Date()).toISOString();
  }
  if (status_id === "delivered" && !delivered_at) {
    delivered_at = (/* @__PURE__ */ new Date()).toISOString();
  }
  const updatedJob = db.updateJob(id, { status_id, completed_at, delivered_at });
  if (updatedJob && status_id !== existingJob.status_id) void dispatchTelegramAlert(
    "status_change",
    `\u{1F504} <b>Repair Status Updated</b>
<b>Ticket:</b> ${escapeTelegramHtml(updatedJob.service_number)}
<b>New Status:</b> ${escapeTelegramHtml(status_id)} (was: ${escapeTelegramHtml(existingJob.status_id)})`
  );
  return res.json(updatedJob);
});
app.delete("/api/jobs/:id", (req, res) => {
  if (req.user?.role !== "admin") {
    db.recordAudit({
      user_id: req.user ? req.user.id : "UNKNOWN",
      username: req.user ? req.user.username : "unknown",
      action: "UNAUTHORIZED_DELETE_ATTEMPT",
      target_type: "job",
      target_id: req.params.id,
      details: `Technician attempted to delete service job ${req.params.id}. Action blocked.`,
      ip_address: req.ip || "127.0.0.1"
    });
    return res.status(403).json({
      error: "Forbidden: Only administrators can delete service jobs."
    });
  }
  const { id } = req.params;
  const deleted = db.deleteJob(id);
  if (!deleted) {
    return res.status(404).json({ error: "Service job not found." });
  }
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    action: "JOB_DELETED",
    target_type: "job",
    target_id: id,
    details: `Admin ${req.user.username} deleted job ${id}.`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.json({ success: true, message: "Job deleted successfully." });
});
app.get("/api/reports/technicians", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Reports are restricted to administrators." });
  }
  const technicians = db.getTechnicians();
  const jobs = db.getJobs();
  const report = technicians.map((tech) => {
    const techJobs = jobs.filter((j) => j.technician_id === tech.id);
    const received = techJobs.filter((j) => j.status_id === "received").length;
    const diagnosing = techJobs.filter((j) => j.status_id === "diagnosing").length;
    const waiting_parts = techJobs.filter((j) => j.status_id === "waiting_parts").length;
    const repairing = techJobs.filter((j) => j.status_id === "repairing").length;
    const ready = techJobs.filter((j) => j.status_id === "ready").length;
    const completed = techJobs.filter((j) => j.status_id === "completed").length;
    const delivered = techJobs.filter((j) => j.status_id === "delivered").length;
    const cancelled = techJobs.filter((j) => j.status_id === "cancelled").length;
    const total_charges = techJobs.reduce((sum, j) => sum + j.service_charge, 0);
    return {
      technician_id: tech.id,
      technician_name: tech.full_name,
      username: tech.username,
      total_jobs: techJobs.length,
      received,
      diagnosing,
      waiting_parts,
      repairing,
      ready,
      completed,
      delivered,
      cancelled,
      total_service_charges: total_charges
    };
  });
  return res.json(report);
});
app.get("/api/audit", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Security audit is restricted to administrators." });
  }
  return res.json(db.getAuditTrail());
});
app.get("/api/payments", (req, res) => {
  const { service_job_id, payment_method, date_from, date_to } = req.query;
  let payments = db.getPayments();
  if (req.user?.role === "technician") {
    const techId = req.user.technician_id;
    const jobs = db.getJobs().filter((j) => j.technician_id === techId);
    const jobIds = new Set(jobs.map((j) => j.id));
    payments = payments.filter((p) => jobIds.has(p.service_job_id));
  }
  if (service_job_id && typeof service_job_id === "string") {
    payments = payments.filter((p) => p.service_job_id === service_job_id);
  }
  if (payment_method && typeof payment_method === "string" && payment_method !== "all") {
    payments = payments.filter((p) => p.payment_method.toLowerCase() === payment_method.toLowerCase());
  }
  if (date_from && typeof date_from === "string") {
    payments = payments.filter((p) => p.paid_at.slice(0, 10) >= date_from);
  }
  if (date_to && typeof date_to === "string") {
    payments = payments.filter((p) => p.paid_at.slice(0, 10) <= date_to);
  }
  return res.json(payments);
});
app.post("/api/payments", (req, res) => {
  if (!req.user || !["admin", "cashier"].includes(req.user.role)) {
    return res.status(403).json({ error: "Forbidden: Payment management is restricted to Admin." });
  }
  const {
    service_job_id,
    payment_method,
    amount,
    currency_code,
    notes,
    payment_note,
    reference_number,
    received_by,
    paid_at
  } = req.body;
  if (!service_job_id) {
    return res.status(400).json({ error: "Service job ID is required." });
  }
  const job = db.getJobById(service_job_id);
  if (!job) {
    return res.status(404).json({ error: "Service job not found." });
  }
  const amountNum = Number(amount);
  if (!Number.isFinite(amountNum) || amountNum <= 0) {
    return res.status(400).json({ error: "Valid payment amount is required." });
  }
  const receiver = (req.user?.role === "cashier" ? req.user.full_name : received_by) || req.user?.full_name || req.user?.username || "Admin";
  const currency = currency_code || db.getSettings().currency || "MMK";
  const finalNote = payment_note || notes || "";
  const newPayment = db.createPayment({
    ...req.user.role === "cashier" ? { cashier_id: req.user.id } : {},
    service_job_id,
    payment_method: payment_method || "Cash",
    amount: amountNum,
    currency_code: currency,
    reference_number: reference_number || "",
    payment_note: finalNote,
    notes: finalNote,
    paid_at: paid_at || (/* @__PURE__ */ new Date()).toISOString(),
    received_by: receiver,
    created_by: req.user.username
  });
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    technician_id: job.technician_id,
    action: "PAYMENT_CREATED",
    target_type: "payment",
    target_id: newPayment.id,
    details: `${escapeTelegramHtml(receiver)} created payment ${newPayment.id} (${escapeTelegramHtml(currency)} ${amountNum}) via ${payment_method || "Cash"}${reference_number ? ` (Ref: ${escapeTelegramHtml(reference_number)})` : ""} for job ${job.service_number}.`,
    ip_address: req.ip || "127.0.0.1"
  });
  const payCust = db.getCustomerById(job.customer_id);
  dispatchTelegramAlert(
    "payment",
    `\u{1F4B0} <b>Customer Payment Recorded</b>
<b>Receipt:</b> <code>${newPayment.id}</code>
<b>Ticket:</b> <code>${job.service_number}</code>
<b>Customer:</b> ${escapeTelegramHtml(payCust?.name || "Customer")}
<b>Amount:</b> <b>${escapeTelegramHtml(currency)} ${amountNum.toLocaleString()}</b>
<b>Method:</b> ${escapeTelegramHtml(newPayment.payment_method)}
` + (reference_number ? `<b>Reference:</b> ${escapeTelegramHtml(reference_number)}
` : "") + `<b>Cashier:</b> ${escapeTelegramHtml(receiver)}`
  );
  return res.status(201).json(newPayment);
});
app.put("/api/payments/:id", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Payment management is restricted to Admin." });
  }
  const paymentId = req.params.id;
  const oldPayment = db.getPaymentById(paymentId);
  if (!oldPayment) {
    return res.status(404).json({ error: "Payment not found." });
  }
  if (oldPayment.is_deleted) return res.status(409).json({ error: "Deleted payments cannot be edited." });
  const { amount, payment_method, reference_number, payment_note, paid_at, reason, service_job_id } = req.body;
  if (service_job_id !== void 0 && !db.getJobById(service_job_id)) {
    return res.status(400).json({ error: "Target service job does not exist." });
  }
  const editReason = reason || "Admin updated payment details";
  if (amount !== void 0 && (!Number.isFinite(Number(amount)) || Number(amount) <= 0)) {
    return res.status(400).json({ error: "Payment amount must be a positive finite number." });
  }
  const updates = {};
  if (amount !== void 0) updates.amount = Number(amount);
  if (payment_method !== void 0) updates.payment_method = payment_method;
  if (reference_number !== void 0) updates.reference_number = reference_number;
  if (payment_note !== void 0) {
    updates.payment_note = payment_note;
    updates.notes = payment_note;
  }
  if (paid_at !== void 0) updates.paid_at = paid_at;
  if (service_job_id !== void 0 && service_job_id !== oldPayment.service_job_id) {
    updates.service_job_id = service_job_id;
  }
  const updated = db.updatePayment(paymentId, updates, req.user.username, editReason);
  if (!updated) {
    return res.status(500).json({ error: "Failed to update payment" });
  }
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    technician_id: updated.technician_id,
    action: "PAYMENT_EDITED",
    target_type: "payment",
    target_id: paymentId,
    details: `Admin @${req.user.username} edited payment ${paymentId}. Old amount: ${oldPayment.currency_code} ${oldPayment.amount}, New amount: ${updated.currency_code} ${updated.amount}. Reason: ${editReason}.`,
    old_value: { amount: oldPayment.amount, method: oldPayment.payment_method, ref: oldPayment.reference_number },
    new_value: { amount: updated.amount, method: updated.payment_method, ref: updated.reference_number },
    reason: editReason,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.json(updated);
});
app.delete("/api/payments/:id", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Payment management is restricted to Admin." });
  }
  const paymentId = req.params.id;
  const oldPayment = db.getPaymentById(paymentId);
  if (!oldPayment) {
    return res.status(404).json({ error: "Payment not found." });
  }
  const deleteReason = req.body?.reason || req.query?.reason || "Admin deleted payment record";
  const deleted = db.deletePayment(paymentId, req.user.username, deleteReason);
  if (!deleted) {
    return res.status(500).json({ error: "Failed to delete payment" });
  }
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    technician_id: oldPayment.technician_id,
    action: "PAYMENT_DELETED",
    target_type: "payment",
    target_id: paymentId,
    details: `Admin @${req.user.username} soft-deleted payment ${paymentId} (${oldPayment.currency_code} ${oldPayment.amount}). Reason: ${deleteReason}.`,
    old_value: { id: oldPayment.id, amount: oldPayment.amount, job: oldPayment.service_job_id },
    reason: deleteReason,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.json({ success: true, payment: deleted });
});
app.post("/api/payments/:id/receipt-printed", (req, res) => {
  if (!req.user || !["admin", "cashier"].includes(req.user.role)) {
    return res.status(403).json({ error: "Forbidden: Only Admin can print official payment receipts." });
  }
  const paymentId = req.params.id;
  const payment = db.getPaymentById(paymentId);
  if (!payment) {
    return res.status(404).json({ error: "Payment not found." });
  }
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    technician_id: payment.technician_id,
    action: "PAYMENT_RECEIPT_PRINTED",
    target_type: "payment",
    target_id: paymentId,
    details: `Admin @${req.user.username} printed official payment receipt for payment ${payment.id} (${payment.currency_code} ${payment.amount}).`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.json({ success: true });
});
app.get("/api/finance/income", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Financial records are restricted to Admin." });
  }
  if (!isPaidPlanActive()) {
    return res.status(403).json({ error: "Forbidden: Income reports require an active PAID license." });
  }
  return res.json(db.getIncome(req.query.include_deleted === "true"));
});
app.post("/api/finance/income", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Financial records are restricted to Admin." });
  }
  const { date, reference, service_number, service_job_id, customer_name, technician_id, description, amount, currency, payment_method } = req.body;
  if (!description || !String(description).trim() || !Number.isFinite(Number(amount)) || Number(amount) <= 0) {
    return res.status(400).json({ error: "A description and positive finite amount are required." });
  }
  const newIncome = db.createIncome({
    date: date || (/* @__PURE__ */ new Date()).toISOString(),
    reference: reference || `INC-${Date.now().toString().slice(-4)}`,
    service_number,
    service_job_id,
    customer_name,
    technician_id,
    description,
    amount: Number(amount) || 0,
    currency: currency || db.getSettings().currency || "MMK",
    payment_method: payment_method || "cash",
    created_by: req.user.username
  });
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    action: "INCOME_CREATED",
    target_type: "finance",
    target_id: newIncome.id,
    details: `Admin @${req.user.username} recorded income ${newIncome.id} (${newIncome.currency} ${newIncome.amount}) for "${description}".`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.status(201).json(newIncome);
});
app.put("/api/finance/income/:id", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Financial records are restricted to Admin." });
  }
  if (req.body.amount !== void 0 && (!Number.isFinite(Number(req.body.amount)) || Number(req.body.amount) <= 0)) return res.status(400).json({ error: "Amount must be a positive finite number." });
  if (req.body.description !== void 0 && (typeof req.body.description !== "string" || !req.body.description.trim())) return res.status(400).json({ error: "Description is required." });
  const allowed = ["date", "reference", "description", "amount", "currency", "payment_method", "category", "service_number", "service_job_id", "customer_name", "technician_id", "technician_name"];
  const updates = Object.fromEntries(Object.entries(req.body).filter(([key]) => allowed.includes(key)));
  if (updates.amount !== void 0) updates.amount = Number(updates.amount);
  const updated = db.updateIncome(req.params.id, updates);
  if (!updated) return res.status(404).json({ error: "Income record not found." });
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    action: "INCOME_EDITED",
    target_type: "finance",
    target_id: req.params.id,
    details: `Admin @${req.user.username} edited income record ${req.params.id}.`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.json(updated);
});
app.delete("/api/finance/income/:id", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Financial records are restricted to Admin." });
  }
  const success = db.deleteIncome(req.params.id, req.user.username);
  if (!success) return res.status(404).json({ error: "Income record not found." });
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    action: "INCOME_DELETED",
    target_type: "finance",
    target_id: req.params.id,
    details: `Admin @${req.user.username} soft-deleted income record ${req.params.id}.`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.json({ success: true });
});
app.get("/api/finance/expense", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Financial records are restricted to Admin." });
  }
  return res.json(db.getExpenses(req.query.include_deleted === "true"));
});
app.post("/api/finance/expense", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Financial records are restricted to Admin." });
  }
  const { date, reference, category, description, amount, currency, payment_method } = req.body;
  if (!description || !String(description).trim() || !Number.isFinite(Number(amount)) || Number(amount) <= 0) {
    return res.status(400).json({ error: "A description and positive finite amount are required." });
  }
  const newExpense = db.createExpense({
    date: date || (/* @__PURE__ */ new Date()).toISOString(),
    reference: reference || `EXP-${Date.now().toString().slice(-4)}`,
    category: category || "Parts",
    description,
    amount: Number(amount) || 0,
    currency: currency || db.getSettings().currency || "MMK",
    payment_method: payment_method || "cash",
    created_by: req.user.username
  });
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    action: "EXPENSE_CREATED",
    target_type: "finance",
    target_id: newExpense.id,
    details: `Admin @${req.user.username} recorded expense ${newExpense.id} (${newExpense.currency} ${newExpense.amount}) [${newExpense.category}] for "${description}".`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.status(201).json(newExpense);
});
app.put("/api/finance/expense/:id", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Financial records are restricted to Admin." });
  }
  if (req.body.amount !== void 0 && (!Number.isFinite(Number(req.body.amount)) || Number(req.body.amount) <= 0)) return res.status(400).json({ error: "Amount must be a positive finite number." });
  if (req.body.description !== void 0 && (typeof req.body.description !== "string" || !req.body.description.trim())) return res.status(400).json({ error: "Description is required." });
  const allowed = ["date", "reference", "description", "amount", "currency", "payment_method", "category", "service_number", "service_job_id", "customer_name", "technician_id", "technician_name"];
  const updates = Object.fromEntries(Object.entries(req.body).filter(([key]) => allowed.includes(key)));
  if (updates.amount !== void 0) updates.amount = Number(updates.amount);
  const updated = db.updateExpense(req.params.id, updates);
  if (!updated) return res.status(404).json({ error: "Expense record not found." });
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    action: "EXPENSE_EDITED",
    target_type: "finance",
    target_id: req.params.id,
    details: `Admin @${req.user.username} edited expense record ${req.params.id}.`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.json(updated);
});
app.delete("/api/finance/expense/:id", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Financial records are restricted to Admin." });
  }
  const success = db.deleteExpense(req.params.id, req.user.username);
  if (!success) return res.status(404).json({ error: "Expense record not found." });
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    action: "EXPENSE_DELETED",
    target_type: "finance",
    target_id: req.params.id,
    details: `Admin @${req.user.username} soft-deleted expense record ${req.params.id}.`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.json({ success: true });
});
app.get("/api/settlements", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Payment settlement is restricted to Admin." });
  }
  return res.json(db.getSettlements());
});
app.post("/api/settlements", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Payment settlement is restricted to Admin." });
  }
  const newSettlement = db.createSettlement({
    ...req.body,
    currency: req.body.currency || db.getSettings().currency || "MMK"
  });
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    action: "SETTLEMENT_CREATED",
    target_type: "finance",
    target_id: newSettlement.id,
    details: `Admin @${req.user.username} initiated ${newSettlement.settlement_type} settlement ${newSettlement.id} (Net: ${newSettlement.currency} ${newSettlement.net_balance}).`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.status(201).json(newSettlement);
});
app.post("/api/settlements/:id/close", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Only Admin can close financial settlements." });
  }
  const closed = db.closeSettlement(req.params.id, req.user.username);
  if (!closed) return res.status(404).json({ error: "Settlement not found." });
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    action: "SETTLEMENT_CLOSED",
    target_type: "finance",
    target_id: closed.id,
    details: `Admin @${req.user.username} finalized and closed settlement ${closed.id}.`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.json(closed);
});
app.get("/api/backup", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Database backup is restricted to Admin." });
  }
  const backup = db.createBackupSnapshot();
  return res.json(backup.metadata);
});
app.post("/api/backup", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Database backup is restricted to Admin." });
  }
  const backup = db.createBackupSnapshot();
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    action: "BACKUP_CREATED",
    target_type: "backup",
    target_id: backup.metadata.id,
    details: `Admin @${req.user.username} generated system database backup (${backup.metadata.size_bytes} bytes, ${backup.metadata.item_counts.service_jobs} jobs).`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.json(backup);
});
app.post("/api/restore", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Database restore is restricted to Admin." });
  }
  const backupData = req.body?.data || req.body;
  const result = db.restoreBackupSnapshot(backupData, req.user.username);
  if (!result.success) {
    return res.status(400).json({ error: result.error });
  }
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    action: "BACKUP_RESTORED",
    target_type: "backup",
    target_id: `RESTORE-${Date.now()}`,
    details: `Admin @${req.user.username} restored system database snapshot. Integrity verified.`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.json({ success: true, message: "Database successfully restored and verified." });
});
app.post("/api/database/clear-demo", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Admin access required." });
  }
  db.clearDemoData();
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    action: "CLEAR_DEMO_DATA",
    target_type: "system",
    target_id: "DB-CLEAR",
    details: `Admin ${req.user.username} cleared all demo records and started with a fresh store database.`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.json({ success: true, message: "Demo data cleared successfully. Store database is now fresh." });
});
var requireAdmin = (req, res, next) => {
  if (req.user?.role !== "admin") return res.status(403).json({ error: "Admin access required." });
  next();
};
var validateCustomerDeletion = (req, res, next) => {
  const ids = req.body.customer_ids;
  if (!Array.isArray(ids) || !ids.length || ids.length > 100 || ids.some((id) => typeof id !== "string" || !id) || new Set(ids).size !== ids.length) {
    return res.status(400).json({ error: "Select 1\u2013100 distinct customers." });
  }
  if (ids.some((id) => !db.getCustomerById(id))) return res.status(404).json({ error: "A selected customer no longer exists. Refresh the list." });
  next();
};
app.post("/api/customers/delete-preview", requireAdmin, validateCustomerDeletion, (req, res) => {
  try {
    return res.json(db.previewCustomerDeletion(req.body.customer_ids));
  } catch (error) {
    return res.status(409).json({ error: error.message });
  }
});
app.post("/api/customers/delete-confirmed", requireAdmin, validateCustomerDeletion, (req, res) => {
  if (typeof req.body.revision !== "string" || !/^[a-f0-9]{64}$/.test(req.body.revision)) return res.status(400).json({ error: "Review and confirm the deletion first." });
  try {
    const result = db.deleteCustomersWithRecords(req.body.customer_ids, req.body.revision, req.user, req.ip || "127.0.0.1");
    return res.json({ success: true, ...result });
  } catch (error) {
    if (/Records changed|another customer/.test(error.message)) return res.status(409).json({ error: error.message });
    return res.status(500).json({ error: "Deletion could not be saved. No records were deleted; check database and backup directory access." });
  }
});
var requireIntakeUser = (req, res, next) => {
  if (!req.user || !["admin", "cashier"].includes(req.user.role)) return res.status(403).json({ error: "Admin or cashier access required." });
  next();
};
app.get("/api/cashiers", requireAdmin, (_req, res) => res.json(db.getUsers().filter((u) => u.role === "cashier")));
app.post("/api/cashiers", requireAdmin, (req, res) => {
  const { username, full_name, password } = req.body;
  if (typeof username !== "string" || !/^[A-Za-z0-9_.-]{3,32}$/.test(username) || typeof full_name !== "string" || !full_name.trim() || full_name.length > 100 || typeof password !== "string" || password.length < 8 || password.length > 128) return res.status(400).json({ error: "Enter a name, unique username (3\u201332 characters), and password (8\u2013128 characters)." });
  if (username === "tech1" || db.getUserByUsername(username)) return res.status(409).json({ error: "Username is already in use." });
  const cashier = db.createCashier({ username, full_name: full_name.trim(), password: hashPassword(password) });
  db.recordAudit({ user_id: req.user.id, username: req.user.username, action: "CASHIER_CREATED", target_type: "auth", target_id: cashier.id, details: "Administrator created a cashier account.", ip_address: req.ip || "127.0.0.1" });
  return res.status(201).json(cashier);
});
app.put("/api/cashiers/:id", requireAdmin, (req, res) => {
  const updates = {};
  for (const field of ["full_name", "phone", "email", "address"]) {
    if (req.body[field] !== void 0) {
      if (typeof req.body[field] !== "string" || req.body[field].length > (field === "address" ? 1e3 : 100) || field === "full_name" && !req.body[field].trim()) return res.status(400).json({ error: "Enter valid cashier profile details." });
      updates[field] = req.body[field].trim();
    }
  }
  if (req.body.profile_photo !== void 0) {
    const invalidPhoto = imageValidationError(req.body.profile_photo);
    if (invalidPhoto) return res.status(400).json({ error: invalidPhoto });
    updates.profile_photo = req.body.profile_photo;
  }
  if (req.body.active !== void 0) {
    if (typeof req.body.active !== "boolean") return res.status(400).json({ error: "Active must be true or false." });
    updates.active = req.body.active;
  }
  if (req.body.password !== void 0) {
    if (typeof req.body.password !== "string" || req.body.password.length < 8 || req.body.password.length > 128) return res.status(400).json({ error: "Password must contain 8\u2013128 characters." });
    updates.password = hashPassword(req.body.password);
  }
  const user = db.updateCashier(req.params.id, updates);
  if (!user) return res.status(404).json({ error: "Cashier not found." });
  if (updates.active !== void 0 || updates.password !== void 0) {
    for (const [token, session] of sessions) if (session.userId === user.id) sessions.delete(token);
  }
  db.recordAudit({ user_id: req.user.id, username: req.user.username, action: "CASHIER_UPDATED", target_type: "auth", target_id: user.id, details: "Administrator updated cashier access/password.", ip_address: req.ip || "127.0.0.1" });
  return res.json(user);
});
app.delete("/api/cashiers/:id", requireAdmin, (req, res) => {
  if (!db.deleteCashier(req.params.id)) return res.status(404).json({ error: "Cashier not found." });
  db.recordAudit({ user_id: req.user.id, username: req.user.username, action: "CASHIER_DELETED", target_type: "auth", target_id: req.params.id, details: "Administrator removed a cashier account; payment history retained.", ip_address: req.ip || "127.0.0.1" });
  return res.json({ success: true });
});
app.get("/api/customers", (_req, res) => res.json(db.getCustomers()));
app.post("/api/customers", requireIntakeUser, (req, res) => {
  if (typeof req.body.name !== "string" || !req.body.name.trim() || typeof req.body.phone !== "string" || !req.body.phone.trim()) {
    return res.status(400).json({ error: "Customer name and phone are required." });
  }
  return res.status(201).json(db.createCustomer(req.body));
});
app.put("/api/customers/:id", requireAdmin, (req, res) => {
  if (req.body.name !== void 0 && (typeof req.body.name !== "string" || !req.body.name.trim())) return res.status(400).json({ error: "Customer name is required." });
  if (req.body.phone !== void 0 && (typeof req.body.phone !== "string" || !req.body.phone.trim())) return res.status(400).json({ error: "Customer phone is required." });
  const updated = db.updateCustomer(req.params.id, req.body);
  if (!updated) return res.status(404).json({ error: "Customer not found." });
  return res.json(updated);
});
app.delete("/api/customers/:id", requireAdmin, (req, res) => {
  if (db.getDevices().some((d) => d.customer_id === req.params.id) || db.getJobs().some((j) => j.customer_id === req.params.id)) {
    return res.status(409).json({ error: "Customer is linked to devices or repair jobs. Remove those records first." });
  }
  if (!db.deleteCustomer(req.params.id)) return res.status(404).json({ error: "Customer not found." });
  return res.json({ success: true });
});
app.get("/api/devices", (_req, res) => res.json(db.getDevices()));
var validateDevice = (req, res, next) => {
  if ((req.method === "POST" || req.body.customer_id !== void 0) && !db.getCustomerById(req.body.customer_id)) {
    return res.status(400).json({ error: "Device customer does not exist." });
  }
  if (req.method === "PUT" && req.body.customer_id !== void 0 && db.getJobs().some((j) => j.device_id === req.params.id && j.customer_id !== req.body.customer_id)) {
    return res.status(409).json({ error: "Cannot transfer a device linked to a repair job." });
  }
  for (const key of ["brand", "model"]) {
    if ((req.method === "POST" || req.body[key] !== void 0) && (typeof req.body[key] !== "string" || !req.body[key].trim())) {
      return res.status(400).json({ error: "Device brand and model are required." });
    }
  }
  next();
};
app.post("/api/devices", requireIntakeUser, validateDevice, (req, res) => res.status(201).json(db.createDevice(req.body)));
app.put("/api/devices/:id", requireAdmin, validateDevice, (req, res) => {
  const updated = db.updateDevice(req.params.id, req.body);
  if (!updated) return res.status(404).json({ error: "Device not found." });
  return res.json(updated);
});
app.delete("/api/devices/:id", requireAdmin, (req, res) => {
  if (db.getJobs().some((j) => j.device_id === req.params.id)) return res.status(409).json({ error: "Device is linked to a repair job." });
  if (!db.deleteDevice(req.params.id)) return res.status(404).json({ error: "Device not found." });
  return res.json({ success: true });
});
app.get("/api/settings", (req, res) => {
  const settings = db.getSettings();
  return res.json(req.user?.role === "admin" ? settings : { ...settings, telegramBot: { ...settings.telegramBot, bot_token: "" } });
});
app.put("/api/settings", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Only administrators can update system settings." });
  }
  for (const field of ["shopName", "phone", "email", "address", "taxId", "receiptFooterNote"]) {
    if (req.body[field] !== void 0 && (typeof req.body[field] !== "string" || req.body[field].length > (["address", "receiptFooterNote"].includes(field) ? 2e3 : 200) || field === "shopName" && !req.body[field].trim())) return res.status(400).json({ error: "Enter valid workshop contact details." });
  }
  if (req.body.taxPercentage !== void 0 && (typeof req.body.taxPercentage !== "number" || !Number.isFinite(req.body.taxPercentage) || req.body.taxPercentage < 0 || req.body.taxPercentage > 100)) return res.status(400).json({ error: "Tax percentage must be between 0 and 100." });
  if (req.body.taxEnabled !== void 0 && typeof req.body.taxEnabled !== "boolean") return res.status(400).json({ error: "Invalid tax setting." });
  const invalidLogo = imageValidationError(req.body.shopLogo);
  if (invalidLogo) return res.status(400).json({ error: invalidLogo });
  if (req.body.paymentSettings) {
    for (const profile of ["thailand", "myanmar", "china", "global"]) {
      const methods = req.body.paymentSettings[profile]?.methods;
      if (methods !== void 0 && !Array.isArray(methods)) return res.status(400).json({ error: "Invalid payment channel list." });
      for (const method of methods || []) {
        if (!method || typeof method.id !== "string") return res.status(400).json({ error: "Invalid payment channel." });
        const invalid = imageValidationError(method.qr_code);
        if (invalid) return res.status(400).json({ error: invalid });
      }
    }
  }
  const updated = db.updateSettings(req.body);
  return res.json(updated);
});
app.get("/api/license", (_req, res) => {
  return res.json(db.getLicense());
});
app.get("/api/admin/licenses", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Admin access required." });
  }
  return res.json({ success: true, licenses: db.getLicensesRegistry() });
});
app.post("/api/admin/licenses/generate", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Admin access required." });
  }
  const { plan, days, license_name } = req.body;
  const licenseDays = Number(days ?? 365);
  if (!Number.isInteger(licenseDays) || licenseDays <= 0) return res.status(400).json({ error: "License duration must be a positive integer." });
  const newLic = db.generateLicenseKey(plan === "PAID" ? "PAID" : "FREE", licenseDays, license_name || "", req.user.username);
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    action: "LICENSE_GENERATED",
    target_type: "system",
    target_id: newLic.license_key,
    details: `Admin generated license key ${newLic.license_key} (${newLic.plan}, ${newLic.days} days).`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.json({ success: true, license: newLic, message: "License key generated successfully." });
});
app.post("/api/admin/licenses/revoke", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Admin access required." });
  }
  const { license_id } = req.body;
  db.revokeLicenseKey(license_id);
  return res.json({ success: true, message: "License key revoked successfully." });
});
app.post("/api/license/verify", async (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: License verification is restricted to Admin." });
  }
  const currentLicense = db.getLicense();
  const updated = db.updateLicense({
    last_verified_at: (/* @__PURE__ */ new Date()).toISOString(),
    owner_verified: false
  });
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    action: "LICENSE_VERIFIED",
    target_type: "system",
    target_id: currentLicense.installation_id,
    details: `License checked against local installation state.`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.json({ success: true, license: updated, message: "License checked locally; owner server has not been contacted." });
});
app.post("/api/license/activate", async (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: License activation is restricted to Admin." });
  }
  const { license_key } = req.body;
  if (!license_key || typeof license_key !== "string" || !license_key.trim()) {
    return res.status(400).json({ error: "License key is required." });
  }
  const cleanKey = license_key.trim();
  const registry = db.getLicensesRegistry();
  const foundReg = registry.find((r) => r.license_key.toUpperCase() === cleanKey.toUpperCase());
  if (!foundReg || foundReg.status !== "ACTIVE") {
    return res.status(400).json({ error: "License key is unknown or revoked. Use a key from the license registry." });
  }
  const { plan, days, status } = foundReg;
  const licenseName = foundReg.license_name;
  const installed = db.getLicense();
  const expires_at = foundReg.expires_at || (installed.license_key.toUpperCase() === cleanKey.toUpperCase() ? installed.expires_at : void 0) || new Date(Date.now() + days * 24 * 60 * 60 * 1e3).toISOString();
  if (!Number.isFinite(Date.parse(expires_at)) || Date.parse(expires_at) <= Date.now()) {
    return res.status(400).json({ error: "License key has expired." });
  }
  foundReg.expires_at = expires_at;
  const updated = db.updateLicense({
    license_key: cleanKey,
    plan,
    status,
    license_name: licenseName,
    license_days: days,
    expires_at,
    last_verified_at: (/* @__PURE__ */ new Date()).toISOString(),
    owner_verified: false
  });
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    action: "LICENSE_ACTIVATED",
    target_type: "system",
    target_id: cleanKey,
    details: `Admin ${req.user.username} activated license ${cleanKey} (Plan: ${plan}, Status: ${status}, Days: ${days}).`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.json({ success: true, license: updated, message: `License activated as ${plan} (${days} days) successfully.` });
});
app.post("/api/license/remove", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: License management is restricted to Admin." });
  }
  const current = db.getLicense();
  const resetLicense = db.updateLicense({
    license_name: "Free Phone Service Management System",
    plan: "FREE",
    status: "NOT_ACTIVATED",
    license_key: "",
    license_days: 0,
    expires_at: null,
    last_verified_at: (/* @__PURE__ */ new Date()).toISOString(),
    owner_verified: false
  });
  db.recordAudit({
    user_id: req.user.id,
    username: req.user.username,
    action: "LICENSE_REMOVED_CLIENT_ONLY",
    target_type: "system",
    target_id: current.installation_id,
    details: `Admin ${req.user.username} removed local license (client-only reset, Owner server was NOT modified).`,
    ip_address: req.ip || "127.0.0.1"
  });
  return res.json({
    success: true,
    license: resetLicense,
    message: "Client license removed successfully. Local state reset to Free / Not Activated."
  });
});
app.get("/api/telegram", (_req, res) => {
  if (_req.user?.role !== "admin") return res.status(403).json({ error: "Admin access required." });
  return res.json(db.getTelegramBot());
});
app.put("/api/telegram", (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Only administrators can configure Telegram Bot." });
  }
  const allowed = ["enabled", "bot_token", "chat_id", "channel_username", "notify_on_new_job", "notify_on_status_change", "notify_on_payment", "notify_on_daily_summary"];
  const updates = {};
  for (const key of allowed) {
    if (req.body[key] === void 0) continue;
    if (["bot_token", "chat_id", "channel_username"].includes(key)) {
      if (typeof req.body[key] !== "string" || req.body[key].length > 512) return res.status(400).json({ error: `Invalid ${key}.` });
      updates[key] = req.body[key].trim();
    } else {
      if (typeof req.body[key] !== "boolean") return res.status(400).json({ error: `Invalid ${key}.` });
      updates[key] = req.body[key];
    }
  }
  if (updates.bot_token && !/^\d+:[A-Za-z0-9_-]+$/.test(updates.bot_token)) return res.status(400).json({ error: "Invalid Telegram Bot Token format." });
  const previous = db.getTelegramBot();
  if ((updates.enabled ?? previous.enabled) && (!(updates.bot_token ?? previous.bot_token) || !(updates.chat_id ?? previous.chat_id))) return res.status(400).json({ error: "Token and Chat ID are required to enable alerts." });
  if (["bot_token", "chat_id", "channel_username"].some((key) => updates[key] !== void 0 && updates[key] !== previous[key])) {
    updates.is_connected = false;
    updates.bot_name = "";
    updates.bot_username = "";
    updates.last_tested_at = "";
  }
  const updated = db.updateTelegramBot(updates);
  return res.json(updated);
});
app.post("/api/telegram/test", async (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Only administrators can test Telegram Bot." });
  }
  const { bot_token, chat_id } = req.body;
  if (typeof bot_token !== "string" || !/^\d+:[A-Za-z0-9_-]+$/.test(bot_token) || bot_token.length > 512) {
    return res.status(400).json({ error: "Telegram Bot Token is required." });
  }
  try {
    if (chat_id !== void 0 && (typeof chat_id !== "string" || chat_id.length > 512)) return res.status(400).json({ error: "Invalid Chat ID." });
    const meData = await telegramRequest(bot_token, "getMe");
    if (!meData.ok) {
      if (db.getTelegramBot().bot_token === bot_token) db.updateTelegramBot({ is_connected: false });
      return res.status(400).json({
        success: false,
        error: `Telegram Error: ${meData.description || "Invalid token"}`,
        message: `Telegram Error: ${meData.description || "Invalid token"}`
      });
    }
    let msgSent = false;
    let msgError = "";
    if (chat_id && chat_id.trim()) {
      const testMsg = `\u{1F514} <b>FixFlow Phone Service Lab</b>
\u2705 Telegram Bot connected and verified successfully!
\u{1F916} <b>Bot:</b> ${escapeTelegramHtml(meData.result.first_name)} (@${escapeTelegramHtml(meData.result.username || "bot")})
\u23F0 <b>Timestamp:</b> ${(/* @__PURE__ */ new Date()).toLocaleString()}`;
      const sendResult = await sendRawTelegramMessage(bot_token, chat_id.trim(), testMsg);
      msgSent = sendResult.ok;
      const saved = db.getTelegramBot();
      if (msgSent && saved.bot_token === bot_token && saved.chat_id.trim() === chat_id.trim() && saved.channel_username?.trim() && saved.channel_username.trim() !== chat_id.trim()) {
        const channelResult = await sendRawTelegramMessage(bot_token, saved.channel_username.trim(), testMsg);
        if (!channelResult.ok) {
          msgSent = false;
          msgError = `Channel delivery failed: ${channelResult.description || "Unknown error"}`;
        }
      }
      if (!msgSent && !msgError) {
        msgError = sendResult.description || "Could not send message to specified Chat ID.";
      }
    }
    const matchesSaved = db.getTelegramBot().bot_token === bot_token && db.getTelegramBot().chat_id.trim() === (chat_id || "").trim();
    const updated = matchesSaved ? db.updateTelegramBot({
      is_connected: Boolean(msgSent),
      bot_name: meData.result.first_name,
      bot_username: meData.result.username,
      last_tested_at: (/* @__PURE__ */ new Date()).toISOString()
    }) : db.getTelegramBot();
    if (chat_id && chat_id.trim() && !msgSent) {
      return res.status(400).json({
        success: false,
        error: `Bot verified (@${meData.result.username}), but failed sending alert to Chat ID ${chat_id}: ${msgError}`,
        message: `Bot verified (@${meData.result.username}), but failed sending alert to Chat ID ${chat_id}: ${msgError}`,
        config: updated
      });
    }
    return res.json({
      success: true,
      bot: meData.result,
      message_sent: msgSent,
      message: msgSent ? `Bot connected and test alert sent successfully to Chat ID: ${chat_id}!` : `Bot token verified (@${meData.result.username}). Please enter or detect a Chat ID to receive workshop alerts.`,
      config: updated
    });
  } catch (err) {
    if (db.getTelegramBot().bot_token === bot_token) db.updateTelegramBot({ is_connected: false });
    return res.status(500).json({
      success: false,
      error: "Could not connect to Telegram. Check internet access.",
      message: "Could not connect to Telegram. Check internet access."
    });
  }
});
app.post("/api/telegram/daily-summary", async (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Only administrators can dispatch daily summaries." });
  }
  const jobs = db.getJobs();
  const payments = db.getPayments();
  const config = db.getTelegramBot();
  if (!config.bot_token || !config.chat_id) {
    return res.status(400).json({ error: "Telegram Bot Token and Chat ID must be configured first." });
  }
  const todayStr = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  const activeJobs = jobs.filter(
    (j) => j.status_id !== "completed" && j.status_id !== "delivered" && j.status_id !== "cancelled"
  );
  const readyJobs = jobs.filter((j) => j.status_id === "ready");
  const completedToday = jobs.filter((j) => (j.completed_at || "").slice(0, 10) === todayStr);
  const todaysPayments = payments.filter((p) => (p.paid_at || "").slice(0, 10) === todayStr);
  const totals = {};
  for (const payment of todaysPayments) {
    const code = payment.currency_code || db.getSettings().currency || "MMK";
    totals[code] = (totals[code] || 0) + Number(payment.amount || 0);
  }
  const totalCollectedToday = totals[db.getSettings().currency || "MMK"] || 0;
  const collectedText = Object.entries(totals).map(([code, amount]) => `${escapeTelegramHtml(code)} ${amount.toLocaleString()}`).join(", ") || "0";
  const currency = db.getSettings().currency || "MMK";
  const summaryHtml = `\u{1F4CA} <b>FixFlow Daily Workshop Summary</b>
\u{1F4C5} <b>Date:</b> ${todayStr}

\u2022 <b>Active Repairs:</b> ${activeJobs.length} job(s)
\u2022 <b>Ready for Pickup:</b> ${readyJobs.length} unit(s)
\u2022 <b>Completed Today:</b> ${completedToday.length} job(s)
\u2022 <b>Payments Collected Today:</b> ${collectedText} (${todaysPayments.length} txns)

<i>Automated FixFlow Service Management Dispatch</i>`;
  const sendResult = await sendRawTelegramMessage(config.bot_token, config.chat_id, summaryHtml);
  const deliveries = [{ chat_id: config.chat_id, ...sendResult }];
  if (config.channel_username && config.channel_username.trim() && config.channel_username.trim() !== config.chat_id.trim()) {
    deliveries.push({ chat_id: config.channel_username.trim(), ...await sendRawTelegramMessage(config.bot_token, config.channel_username.trim(), summaryHtml) });
  }
  if (deliveries.some((d) => !d.ok)) {
    db.updateTelegramBot({ is_connected: false });
    return res.status(400).json({
      success: false,
      deliveries,
      error: `Failed sending Telegram summary: ${deliveries.filter((d) => !d.ok).map((d) => d.description).join("; ")}`,
      message: `Failed sending Telegram summary: ${deliveries.filter((d) => !d.ok).map((d) => d.description).join("; ")}`,
      summary: {
        active_jobs: activeJobs.length,
        ready_jobs: readyJobs.length,
        completed_today: completedToday.length,
        revenue_today: totalCollectedToday,
        revenue_by_currency: totals
      }
    });
  }
  return res.json({
    success: true,
    deliveries,
    message: `Daily summary dispatched successfully to Telegram (${config.chat_id})!`,
    summary: {
      active_jobs: activeJobs.length,
      ready_jobs: readyJobs.length,
      completed_today: completedToday.length,
      revenue_today: totalCollectedToday,
      revenue_by_currency: totals
    }
  });
});
app.post("/api/telegram/get-chat-ids", async (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Only administrators can access Telegram tools." });
  }
  const { bot_token } = req.body;
  if (typeof bot_token !== "string" || !/^\d+:[A-Za-z0-9_-]+$/.test(bot_token) || bot_token.length > 512) {
    return res.status(400).json({ error: "Telegram Bot Token is required." });
  }
  try {
    const updatesData = await telegramRequest(bot_token, "getUpdates", { limit: 100, timeout: 0 });
    if (!updatesData.ok) {
      return res.status(400).json({ success: false, error: updatesData.description || "Failed to fetch updates from Telegram" });
    }
    const chatsMap = /* @__PURE__ */ new Map();
    if (Array.isArray(updatesData.result)) {
      for (const update of updatesData.result) {
        const msg = update.message || update.edited_message || update.channel_post || update.edited_channel_post || update.my_chat_member || update.chat_member || update.callback_query?.message;
        if (msg && msg.chat) {
          const chat = msg.chat;
          const chatId = String(chat.id);
          const title = chat.title || [chat.first_name, chat.last_name].filter(Boolean).join(" ") || chat.username || "Direct Chat";
          chatsMap.set(chatId, {
            chat_id: chatId,
            title,
            username: chat.username ? `@${chat.username}` : "",
            type: chat.type,
            last_message: msg.text || (msg.caption ? `[Media] ${msg.caption}` : ""),
            date: msg.date ? new Date(msg.date * 1e3).toISOString() : (/* @__PURE__ */ new Date()).toISOString()
          });
        }
      }
    }
    const chats = Array.from(chatsMap.values()).reverse();
    return res.json({
      success: true,
      chats,
      count: chats.length
    });
  } catch (err) {
    return res.status(500).json({ success: false, error: "Could not fetch Telegram updates. Check internet access." });
  }
});
app.get("/api/download-project", (_req, res) => {
  if (_req.user?.role !== "admin") return res.status(403).json({ error: "Admin access required." });
  const filePath = import_path2.default.resolve("fixflow-project.zip");
  if (import_fs2.default.existsSync(filePath)) {
    res.download(filePath, "fixflow-project.zip");
  } else {
    res.status(404).json({ error: "Project ZIP not found." });
  }
});
var phpCliProcess = null;
var phpCliActivePort = 8080;
function getSystemNetworkInterfaces() {
  const ifaces = import_os.default.networkInterfaces();
  const list = [];
  for (const name in ifaces) {
    for (const info of ifaces[name] || []) {
      if (info.family === "IPv4" && !info.internal) {
        list.push({ name, ip: info.address });
      }
    }
  }
  let primaryIp = "127.0.0.1";
  const lanCandidate = list.find((item) => item.ip.startsWith("192.168.")) || list.find((item) => !item.name.toLowerCase().includes("vpn") && !item.name.toLowerCase().includes("tap") && (item.ip.startsWith("10.") || item.ip.startsWith("172."))) || list.find((item) => item.ip.startsWith("172.")) || list.find((item) => item.ip.startsWith("10."));
  if (lanCandidate) {
    primaryIp = lanCandidate.ip;
    lanCandidate.is_primary = true;
  } else if (list.length > 0) {
    primaryIp = list[0].ip;
    list[0].is_primary = true;
  }
  return { list, primaryIp };
}
function checkPhpCli() {
  let installed = false;
  let version = "";
  try {
    const raw = (0, import_child_process.execSync)("php -v", { encoding: "utf-8", timeout: 3e3 });
    installed = true;
    version = raw.split("\n")[0].trim();
  } catch (e) {
    installed = false;
  }
  return { installed, version };
}
app.get("/api/system/network-info", (_req, res) => {
  const { list, primaryIp } = getSystemNetworkInterfaces();
  const php = checkPhpCli();
  const isPhpRunning = phpCliProcess !== null && !phpCliProcess.killed;
  return res.json({
    hostname: import_os.default.hostname(),
    platform: process.platform,
    interfaces: list,
    primary_ip: primaryIp,
    node_port: port,
    node_lan_url: `http://${primaryIp}:${port}`,
    php_cli: {
      installed: php.installed,
      version: php.version,
      is_running: isPhpRunning,
      port: phpCliActivePort,
      lan_url: `http://${primaryIp}:${phpCliActivePort}`,
      command: `php -S 0.0.0.0:${phpCliActivePort} router.php`,
      batch_script: "start-pos-php-cli.bat"
    },
    firewall_command: `netsh advfirewall firewall add rule name="FixFlow POS Multi-Device" dir=in action=allow protocol=TCP localport=3000,${phpCliActivePort}`
  });
});
app.post("/api/system/php-cli/start", (req, res) => {
  if (req.user?.role !== "admin") return res.status(403).json({ error: "Admin access required." });
  const requestedPort = Number(req.body?.port ?? 8080);
  if (!Number.isInteger(requestedPort) || requestedPort < 1 || requestedPort > 65535) return res.status(400).json({ error: "Invalid port." });
  const php = checkPhpCli();
  if (!php.installed) {
    return res.status(400).json({
      success: false,
      error: "PHP CLI is not installed or not found in system PATH. Please ensure PHP is installed on Windows (no XAMPP required)."
    });
  }
  if (phpCliProcess && !phpCliProcess.killed) {
    const { primaryIp } = getSystemNetworkInterfaces();
    return res.json({
      success: true,
      message: `PHP CLI server is already running on port ${phpCliActivePort}`,
      port: phpCliActivePort,
      lan_url: `http://${primaryIp}:${phpCliActivePort}`,
      is_running: true
    });
  }
  phpCliActivePort = requestedPort;
  try {
    phpCliProcess = (0, import_child_process.spawn)("php", ["-S", `0.0.0.0:${requestedPort}`, "router.php"], {
      cwd: process.cwd(),
      stdio: "ignore",
      detached: false
    });
    phpCliProcess.on("exit", () => {
      phpCliProcess = null;
    });
    phpCliProcess.on("error", (err) => {
      console.warn("PHP CLI process error:", err);
      phpCliProcess = null;
    });
    const { primaryIp } = getSystemNetworkInterfaces();
    return res.json({
      success: true,
      message: `PHP CLI multi-device server started on port ${requestedPort}`,
      port: requestedPort,
      lan_url: `http://${primaryIp}:${requestedPort}`,
      is_running: true
    });
  } catch (err) {
    phpCliProcess = null;
    return res.status(500).json({
      success: false,
      error: `Failed to start PHP CLI server: ${err.message}`
    });
  }
});
app.post("/api/system/php-cli/stop", (_req, res) => {
  if (_req.user?.role !== "admin") return res.status(403).json({ error: "Admin access required." });
  if (phpCliProcess && !phpCliProcess.killed) {
    try {
      phpCliProcess.kill();
    } catch (e) {
    }
    phpCliProcess = null;
    return res.json({
      success: true,
      message: "PHP CLI multi-device server stopped.",
      is_running: false
    });
  }
  phpCliProcess = null;
  return res.json({
    success: true,
    message: "PHP CLI server is not currently running.",
    is_running: false
  });
});
app.use("/api", (_req, res) => res.status(404).json({ error: "API endpoint not found." }));
app.use((err, _req, res, _next) => {
  console.error("[Request error]", err.message);
  const status = err.status === 400 ? 400 : err.status === 413 ? 413 : 500;
  return res.status(status).json({ error: status === 400 ? "Invalid JSON request body." : status === 413 ? "Request body is too large." : "Could not complete the request." });
});
async function startServer() {
  if (process.env.NODE_ENV === "production") {
    const dist = import_path2.default.resolve(process.env.FIXFLOW_DIST_DIR || "dist");
    if (!import_fs2.default.existsSync(import_path2.default.join(dist, "index.html"))) throw new Error("Run npm run build before production start.");
    app.use(import_express.default.static(dist));
    app.get("*", (_req, res) => res.sendFile(import_path2.default.join(dist, "index.html")));
  } else {
    const vite = await (0, import_vite.createServer)({ server: { middlewareMode: true }, appType: "spa" });
    app.use(vite.middlewares);
  }
  const host = process.env.FIXFLOW_HOST || "0.0.0.0";
  app.listen(port, host, () => {
    console.log(`FixFlow Phone Service Management Server running at http://0.0.0.0:${port}`);
  });
}
startServer().catch((err) => {
  console.error(err);
  process.exit(1);
});
